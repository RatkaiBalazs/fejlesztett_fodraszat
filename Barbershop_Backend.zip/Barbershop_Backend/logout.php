<?php
session_start();

// 1. Töröljük a munkamenet adatait (kiléptetés)
session_unset();
session_destroy();

// 2. Átirányítás a HELYES címre (amit most megadtál)
header("Location: http://localhost:5173/");
exit();
?>