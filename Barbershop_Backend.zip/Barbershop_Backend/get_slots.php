<?php
// ==========================================
// 1. BEÁLLÍTÁSOK
// ==========================================
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

require 'db.php'; 

// FONTOS: Időzóna, hogy szinkronban legyen a valódi idővel
date_default_timezone_set('Europe/Budapest');

// Nyitvatartás (Óra:Perc)
$opening_hours = [
    1 => ['start' => '09:00', 'end' => '20:00'], // Hétfő
    2 => ['start' => '09:00', 'end' => '20:00'], // Kedd
    3 => ['start' => '09:00', 'end' => '20:00'], // Szerda
    4 => ['start' => '09:00', 'end' => '20:00'], // Csütörtök
    5 => ['start' => '09:00', 'end' => '20:00'], // Péntek
    6 => ['start' => '10:00', 'end' => '16:00'], // Szombat
    0 => null // Vasárnap ZÁRVA
];

// ==========================================
// 2. ADATOK LEKÉRÉSE
// ==========================================

// Fodrászok
$barbers = [];
$sql_barbers = "SELECT Fodrasz_ID, Fodrasz_Nev FROM fodraszok"; // Ha nálad más a tábla/oszlop neve, írd át!
$result_barbers = $conn->query($sql_barbers);

if ($result_barbers) {
    while($row = $result_barbers->fetch_assoc()) {
        $id = $row['Fodrasz_ID'] ?? $row['ID']; 
        $name = $row['Fodrasz_Nev'] ?? $row['Nev'];
        $barbers[$id] = $name;
    }
} else {
    // Fallback tesztnek
    $barbers = [1 => "Kovács Dávid", 2 => "Teszt Fodrász"];
}

// Foglalások a következő 14 napra
// Csak azokat kérjük le, amik NEM lettek törölve (ha van Statusz oszlopod)
// Ha nincs Statusz oszlopod, töröld ki a "AND Statusz != 'Torolt'" részt!
$bookings = [];
$sql_bookings = "SELECT Fodrasz_ID, Kezdes, Befejezes FROM Idopont 
                 WHERE Kezdes >= NOW() 
                 AND Kezdes <= DATE_ADD(NOW(), INTERVAL 14 DAY)";

// Ha van státuszod, érdemes kiszűrni a törölteket:
// $sql_bookings .= " AND Statusz != 'Torolt'";

$result_bookings = $conn->query($sql_bookings);

if ($result_bookings) {
    while($row = $result_bookings->fetch_assoc()) {
        $bookings[] = $row;
    }
}

// ==========================================
// 3. SZABAD HELYEK GENERÁLÁSA (ÜTKÖZÉSVIZSGÁLATTAL)
// ==========================================
$available_slots = [];
$today = new DateTime();
$end_date = (new DateTime())->modify('+14 days');
$interval = new DateInterval('P1D');
$period = new DatePeriod($today, $interval, $end_date);

$now_timestamp = time(); // A mostani pillanat

foreach ($period as $date) {
    $day_of_week = $date->format('w'); 
    $date_str = $date->format('Y-m-d');

    // Ha zárva van, ugrunk
    if (!isset($opening_hours[$day_of_week]) || $opening_hours[$day_of_week] === null) continue;

    $open_time = $opening_hours[$day_of_week]['start'];
    $close_time = $opening_hours[$day_of_week]['end'];

    foreach ($barbers as $barber_id => $barber_name) {
        
        $current_time = strtotime("$date_str $open_time");
        $end_time_stamp = strtotime("$date_str $close_time");

        // 30 perces ciklus
        while ($current_time < $end_time_stamp) {
            
            // Múltbeli időpontokat ne mutassunk
            // +10 perc puffer, hogy ne lehessen az éppen mostira foglalni
            if ($current_time < ($now_timestamp + 600)) { 
                $current_time = strtotime('+30 minutes', $current_time);
                continue; 
            }

            // A generált 30 perces "szelet" eleje és vége
            $slot_start_ts = $current_time;
            $slot_end_ts = strtotime('+30 minutes', $current_time);

            $is_free = true;

            // --- 🛑 SZIGORÚ ÜTKÖZÉS VIZSGÁLAT 🛑 ---
            foreach ($bookings as $booking) {
                // Csak az adott fodrászt nézzük
                if ($booking['Fodrasz_ID'] != $barber_id) continue;

                $b_start_ts = strtotime($booking['Kezdes']);
                $b_end_ts = strtotime($booking['Befejezes']);

                // MATEMATIKA: Két idősáv metszi egymást, ha:
                // (StartA < EndB) ÉS (EndA > StartB)
                // Ez lefedi azt is, ha teljesen benne van, ha rálóg az elejére, vagy a végére.
                if ($slot_start_ts < $b_end_ts && $slot_end_ts > $b_start_ts) {
                    $is_free = false;
                    break; // Találtunk ütközést, nem kell tovább keresni
                }
            }

            // Ha szabad, hozzáadjuk a listához
            if ($is_free) {
                $available_slots[] = [
                    'date' => $date->format('Y.m.d'),
                    'day' => $date->format('l'),
                    'time' => date('H:i', $current_time),
                    'barber_id' => $barber_id,
                    'barber_name' => $barber_name
                ];
            }

            $current_time = strtotime('+30 minutes', $current_time);
        }
    }
}

echo json_encode($available_slots);
?>