<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

require 'db.php';

if (!isset($_GET['fodrasz_nev'])) { // ID helyett Név
    echo json_encode([]);
    exit();
}

$fodrasz_nev = $conn->real_escape_string($_GET['fodrasz_nev']);

// Összekötjük az Ugyfel táblával, hogy a nevet is ki tudjuk írni (pl. "Nagy Ádám")
// Figyelj a mezőnevekre: Szoveges_velemeny, Ertekeles
$sql = "SELECT v.*, u.Ugyfel_Nev 
        FROM velemenyek v 
        JOIN ugyfel u ON v.Ugyfel_ID = u.Ugyfel_ID 
        WHERE v.Fodrasz_Neve = '$fodrasz_nev' 
        ORDER BY v.Datum DESC";

$result = $conn->query($sql);

$reviews = [];
if ($result) {
    while($row = $result->fetch_assoc()) {
        $reviews[] = $row;
    }
}

echo json_encode($reviews);
?>