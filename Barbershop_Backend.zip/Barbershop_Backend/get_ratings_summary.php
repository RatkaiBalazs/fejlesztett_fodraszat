<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

require 'db.php';

// Csoportosítva lekérjük az átlagot és a darabszámot minden fodrászhoz (Név alapján)
$sql = "SELECT Fodrasz_Neve, AVG(Ertekeles) as atlag, COUNT(*) as db 
        FROM velemenyek 
        GROUP BY Fodrasz_Neve";

$result = $conn->query($sql);

$summary = [];
if ($result) {
    while($row = $result->fetch_assoc()) {
        // A kulcs a fodrász neve lesz, így könnyű lesz megtalálni Reactban
        $summary[$row['Fodrasz_Neve']] = [
            'atlag' => round((float)$row['atlag'], 1), // 1 tizedesjegyre kerekítve (pl. 4.5)
            'db' => (int)$row['db']
        ];
    }
}

echo json_encode($summary);
?>