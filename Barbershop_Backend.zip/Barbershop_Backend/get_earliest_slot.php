<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

// FONTOS: Hibaüzenetek megjelenítése a válaszban debugoláshoz
error_reporting(E_ALL);
ini_set('display_errors', 0); // Ne rondítson bele a JSON-be, de logoljon

// Próbáljuk meg betölteni a db.php-t, de ha nem sikerül, manuálisan kapcsolódunk
if (file_exists('db.php')) {
    require 'db.php';
} else {
    // Ha nincs db.php, próbálj meg itt csatlakozni (Írd át az adatokat ha szükséges!)
    $conn = new mysqli("localhost", "root", "", "barbershop");
    $conn->set_charset("utf8");
}

if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Adatbázis kapcsolódási hiba: ' . $conn->connect_error]);
    exit();
}

date_default_timezone_set('Europe/Budapest');

// Nyitvatartás
$opening_hours = [
    1 => ['start' => '09:00', 'end' => '20:00'], 
    2 => ['start' => '09:00', 'end' => '20:00'], 
    3 => ['start' => '09:00', 'end' => '20:00'], 
    4 => ['start' => '09:00', 'end' => '20:00'], 
    5 => ['start' => '09:00', 'end' => '20:00'], 
    6 => ['start' => '10:00', 'end' => '16:00'], 
    0 => null 
];

// 1. Fodrászok lekérése (HIBAKERESÉSSEL)
$barbers = [];
$sql_barbers = "SELECT * FROM fodraszok"; // Egyszerűsített lekérdezés
$result_barbers = $conn->query($sql_barbers);

if ($result_barbers && $result_barbers->num_rows > 0) {
    while($row = $result_barbers->fetch_assoc()) {
        // Kezeljük, ha Fodrasz_ID vagy ID a mező neve
        $id = isset($row['Fodrasz_ID']) ? $row['Fodrasz_ID'] : (isset($row['ID']) ? $row['ID'] : null);
        
        if ($id) {
            $barbers[$id] = $row; 
        }
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Hiba: Nem találtam egyetlen fodrászt sem az adatbázisban!']);
    exit();
}

// 2. Foglalások lekérése
$bookings = [];
$sql_bookings = "SELECT Fodrasz_ID, Kezdes, Befejezes FROM Idopont 
                 WHERE Kezdes >= NOW() 
                 AND Kezdes <= DATE_ADD(NOW(), INTERVAL 14 DAY)";
$result_bookings = $conn->query($sql_bookings);

if ($result_bookings) {
    while($row = $result_bookings->fetch_assoc()) {
        $bookings[] = $row;
    }
}

// 3. KERESÉS
$today = new DateTime();
$end_date = (new DateTime())->modify('+14 days');
$interval = new DateInterval('P1D');
$period = new DatePeriod($today, $interval, $end_date);

$now_timestamp = time(); 

function roundToNext30Minutes($timestamp) {
    $minutes = (int)date('i', $timestamp);
    $seconds = (int)date('s', $timestamp);
    if ($minutes == 0 && $seconds == 0) return $timestamp;
    if ($minutes == 30 && $seconds == 0) return $timestamp;
    $remainder = $timestamp % 1800;
    return $timestamp + (1800 - $remainder);
}

foreach ($period as $date) {
    $day_of_week = $date->format('w'); 
    $date_str = $date->format('Y-m-d');

    if (!isset($opening_hours[$day_of_week]) || $opening_hours[$day_of_week] === null) continue;

    $open_ts = strtotime("$date_str " . $opening_hours[$day_of_week]['start']);
    $close_ts = strtotime("$date_str " . $opening_hours[$day_of_week]['end']);

    $search_start_ts = $open_ts;

    // Ha MA van, akkor a mostani időtől keressünk
    if ($date_str === date('Y-m-d')) {
        $next_slot = roundToNext30Minutes($now_timestamp);
        $search_start_ts = max($open_ts, $next_slot);
    }

    for ($current_ts = $search_start_ts; $current_ts < $close_ts; $current_ts += 1800) {
        $slot_start = $current_ts;
        $slot_end = $current_ts + 1800; 

        if ($slot_end > $close_ts) continue;

        foreach ($barbers as $barber_id => $barber_data) {
            $is_free = true;

            foreach ($bookings as $booking) {
                // Ellenőrizzük, hogy a string ID egyezik-e
                if ($booking['Fodrasz_ID'] != $barber_id) continue;
                
                $b_start = strtotime($booking['Kezdes']);
                $b_end = strtotime($booking['Befejezes']);

                if ($slot_start < $b_end && $slot_end > $b_start) {
                    $is_free = false;
                    break; 
                }
            }

            if ($is_free) {
                // SIKER!
                echo json_encode([
                    'success' => true,
                    'date' => date('Y-m-d', $slot_start),
                    'time' => date('H:i', $slot_start),
                    'barber' => [
                        'id' => $barber_id,
                        'name' => $barber_data['Fodrasz_Nev'] ?? $barber_data['Nev'] ?? 'Névtelen',
                        'role' => "Barber", 
                        'desc' => $barber_data['Fodrasz_Leiras'] ?? "Profi szakember",
                        'image' => $barber_data['Fodrasz_Kepe'] ?? ""
                    ]
                ]);
                exit();
            }
        }
    }
}

// Ha ide eljut, akkor tényleg nem talált semmit
echo json_encode([
    'success' => false, 
    'message' => 'Sajnos tényleg nincs szabad időpont a következő 2 hétben. (Ellenőrizve: ' . count($barbers) . ' fodrász, ' . count($bookings) . ' foglalás)'
]);
?>