<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

require 'db.php';

if (isset($_GET['user_id'])) {
    $user_id = (int)$_GET['user_id'];

    // CSAK AZ OLVASATLANOKAT KÉRJÜK LE (olvasva = 0)
    $sql = "SELECT * FROM ertesitesek 
            WHERE cimzett_id = $user_id 
            AND cimzett_tipus = 'ugyfel' 
            AND olvasva = 0 
            ORDER BY datum DESC LIMIT 5";
            
    $result = $conn->query($sql);
    
    $notifications = [];
    while ($row = $result->fetch_assoc()) {
        $notifications[] = $row;
    }
    echo json_encode($notifications);
} else {
    echo json_encode([]);
}
$conn->close();
?>