<?php
// 1. Munkamenet indítása (FONTOS: Ez kell, hogy a Fodrász Dashboard felismerje őket!)
session_start();

// CORS és Header beállítások (hogy a React elérje)
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

require 'db.php';

// Adatok fogadása
$data = json_decode(file_get_contents("php://input"));

if(!isset($data->email) || !isset($data->password)) {
    echo json_encode(["success" => false, "message" => "Hiányzó adatok!"]);
    exit();
}

$beirt_adat = $conn->real_escape_string($data->email); // Ez lehet Email (vendégnél) vagy Név (fodrásznál)
$password = $conn->real_escape_string($data->password);

// --- 1. KÖR: VENDÉG KERESÉSE (EZ A TE RÉGI KÓDOD LOGIKÁJA) ---
$sql_ugyfel = "SELECT * FROM Ugyfel WHERE Ugyfel_Email = '$beirt_adat'";
$result_ugyfel = $conn->query($sql_ugyfel);

if ($result_ugyfel->num_rows > 0) {
    // >>> TALÁLTUNK VENDÉGET
    $user = $result_ugyfel->fetch_assoc();
    
    // Jelszó ellenőrzése (az eredeti 'Ugyfel_jelszo1' oszlop alapján)
    if ($password === $user['Ugyfel_jelszo1']) {
        echo json_encode([
            "success" => true, 
            "role" => "guest", // Jelezzük, hogy ez vendég
            "message" => "Sikeres vendég bejelentkezés!",
            "user" => [
                "id" => $user['Ugyfel_ID'],
                "name" => $user['Ugyfel_Nev'],
                "email" => $user['Ugyfel_Email']
            ]
        ]);
    } else {
        echo json_encode(["success" => false, "message" => "Hibás jelszó!"]);
    }

} else {
    // --- 2. KÖR: FODRÁSZ KERESÉSE (ÚJ RÉSZ) ---
    // Ha nem volt vendég, megnézzük, hátha fodrász neve volt beírva
    $sql_fodrasz = "SELECT * FROM fodraszok WHERE Fodrasz_Nev = '$beirt_adat'";
    $result_fodrasz = $conn->query($sql_fodrasz);

    if ($result_fodrasz->num_rows > 0) {
        // >>> TALÁLTUNK FODRÁSZT
        $fodrasz = $result_fodrasz->fetch_assoc();

        // Jelszó ellenőrzése (a 'jelszo' oszlop alapján)
        if ($password === $fodrasz['jelszo']) {
            
            // ELMENTJÜK A SESSION-T (Ez kell a dashboard.php-hoz!)
            $_SESSION['user_id'] = $fodrasz['Fodrasz_ID'];
            $_SESSION['user_nev'] = $fodrasz['Fodrasz_Nev'];

            // Visszaküldjük az infót a Reactnak, hogy irányítson át
            echo json_encode([
                "success" => true,
                "role" => "barber", // Jelezzük: ez fodrász!
                // Hozzáfűzzük az ID-t a link végére (?login_id=...), hogy a dashboard felismerjen
                "redirect_url" => "http://localhost/BARBERSHOP_BACKEND/dashboard.php?login_id=" . $fodrasz['Fodrasz_ID'],
                "message" => "Sikeres fodrász belépés!",
                "user" => [
                    "id" => $fodrasz['Fodrasz_ID'],
                    "name" => $fodrasz['Fodrasz_Nev']
                ]
            ]);
        } else {
            echo json_encode(["success" => false, "message" => "Hibás fodrász jelszó!"]);
        }
    } else {
        // Se nem vendég, se nem fodrász
        echo json_encode(["success" => false, "message" => "Nincs ilyen felhasználó!"]);
    }
}

$conn->close();
?>