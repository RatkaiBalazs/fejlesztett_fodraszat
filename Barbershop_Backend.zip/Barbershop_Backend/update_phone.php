<?php
// 1. CORS és PREFLIGHT
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require 'db.php';

// 2. ADATOK BEOLVASÁSA
$json = file_get_contents("php://input");
$data = json_decode($json);

// Ellenőrzés
if ($data === null || !isset($data->email) || !isset($data->new_phone)) {
    echo json_encode(["success" => false, "message" => "Hiányzó adatok!"]);
    exit();
}

$email = $conn->real_escape_string($data->email);
$new_phone = $conn->real_escape_string($data->new_phone);

// 3. TELEFONSZÁM FRISSÍTÉSE
// Csak azt a felhasználót frissítjük, akinek ez az email címe
$sql = "UPDATE Ugyfel SET Ugyfel_Telszam = '$new_phone' WHERE Ugyfel_Email = '$email'";

if ($conn->query($sql) === TRUE) {
    echo json_encode(["success" => true, "message" => "Telefonszám sikeresen módosítva!"]);
} else {
    echo json_encode(["success" => false, "message" => "Hiba történt: " . $conn->error]);
}

$conn->close();
?>