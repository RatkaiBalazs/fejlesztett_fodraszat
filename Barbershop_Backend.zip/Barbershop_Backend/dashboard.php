<?php
session_start();

// Ellenőrizzük, hogy be van-e lépve a fodrász.
// Ha nincs bejelentkezve (nincs elmentve az ID), visszaküldjük a loginra.
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Csatlakozás a te "barbershop" adatbázisodhoz
$conn = new mysqli("localhost", "root", "", "barbershop");

if ($conn->connect_error) {
    die("Kapcsolódási hiba: " . $conn->connect_error);
}

// Kivesszük a "zsebből", hogy ki lépett be
$aktualis_id = $_SESSION['user_id'];

// Lekérjük a fodrász adatait
$sql = "SELECT * FROM fodraszok WHERE Fodrasz_ID = $aktualis_id";
$result = $conn->query($sql);
$fodrasz = $result->fetch_assoc();

// (Opcionális) Itt kérdezhetnénk le a hozzá tartozó időpontokat is az "idopont" táblából
// $sql_idopontok = "SELECT * FROM idopont WHERE Fodrasz_ID = $aktualis_id";
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Vezérlőpult</title>
    <style>
        body { font-family: sans-serif; padding: 20px; background-color: #f4f4f4; }
        .doboz { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); max-width: 600px; margin: 0 auto; }
        h1 { color: #333; }
        .gomb { display: inline-block; padding: 10px 20px; background: #d9534f; color: white; text-decoration: none; border-radius: 5px; margin-top: 20px; }
    </style>
</head>
<body>

    <div class="doboz">
        <h1>Üdvözöllek, <?php echo $fodrasz['Fodrasz_Nev']; ?>!</h1>
        
        <p><strong>Beosztás/Specializáció:</strong> <?php echo $fodrasz['Fodrasz_Spec']; ?></p>
        <p><strong>Azonosítód:</strong> #<?php echo $fodrasz['Fodrasz_ID']; ?></p>

        <hr>
        
        <h3>Itt láthatnád a saját foglalásaidat...</h3>
        <p>Ez a te személyes vezérlőpultod. Csak te látod ezeket az adatokat.</p>

        <a href="login.php?logout=1" class="gomb">Kijelentkezés</a>
    </div>

</body>
</html>