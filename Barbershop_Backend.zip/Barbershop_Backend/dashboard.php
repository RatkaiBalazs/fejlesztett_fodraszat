<?php
session_start();

// 1. ADATBÁZIS KAPCSOLAT
$conn = new mysqli("localhost", "root", "", "barbershop");
$conn->set_charset("utf8");

if ($conn->connect_error) { die("Hiba: " . $conn->connect_error); }

// 2. IDŐZÓNA BEÁLLÍTÁSA (FONTOS!)
date_default_timezone_set('Europe/Budapest');

// Login redirect logika
if (isset($_GET['login_id'])) {
    $login_id = (int)$_GET['login_id'];
    $sql_check = "SELECT Fodrasz_Nev FROM fodraszok WHERE Fodrasz_ID = $login_id";
    $res_check = $conn->query($sql_check);
    if ($res_check->num_rows > 0) {
        $user_data = $res_check->fetch_assoc();
        $_SESSION['user_id'] = $login_id;
        $_SESSION['user_nev'] = $user_data['Fodrasz_Nev'];
        header("Location: dashboard.php");
        exit();
    }
}

// Ha nincs bejelentkezve, megállunk
if (!isset($_SESSION['user_id'])) { die("Hiba: Nem vagy bejelentkezve!"); }

$barber_id = $_SESSION['user_id'];
$barber_name = $_SESSION['user_nev'];

// 3. PONTOS IDŐ MEGHATÁROZÁSA (Dátum + Óra:Perc:Mp)
// Ez a kulcs: nem csak a napot nézzük, hanem a pontos időt is!
$now = date('Y-m-d H:i:s'); 

// 4. LEKÉRDEZÉSEK MÓDOSÍTÁSA ($today HELYETT $now)

// Napi Teendők: Csak azok, amik MÉG NEM kezdődtek el (vagy pont most kezdődnek)
$sql_upcoming = "SELECT idopont.Idopont_ID, idopont.Kezdes, idopont.Befejezes, ugyfel.Ugyfel_Nev, ugyfel.Ugyfel_Email 
                 FROM idopont JOIN ugyfel ON idopont.Ugyfel_ID = ugyfel.Ugyfel_ID 
                 WHERE idopont.Fodrasz_ID = $barber_id 
                 AND idopont.Kezdes >= '$now' 
                 ORDER BY idopont.Kezdes ASC";
$result_upcoming = $conn->query($sql_upcoming);

// Korábbi Foglalások: Amik MÁR ELKEZDŐDTEK (kisebb mint most)
$sql_past = "SELECT idopont.Kezdes, idopont.Befejezes, ugyfel.Ugyfel_Nev, ugyfel.Ugyfel_Email 
             FROM idopont JOIN ugyfel ON idopont.Ugyfel_ID = ugyfel.Ugyfel_ID 
             WHERE idopont.Fodrasz_ID = $barber_id 
             AND idopont.Kezdes < '$now' 
             ORDER BY idopont.Kezdes DESC";
$result_past = $conn->query($sql_past);
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fodrász Vezérlőpult</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Segoe UI', sans-serif; background-color: #f4f4f4; padding: 20px; }
        .main-container { max-width: 1000px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); }
        h1 { color: #333; border-bottom: 2px solid #d4af37; padding-bottom: 10px; margin-bottom: 20px; }
        .welcome { font-size: 1.2em; margin-bottom: 20px; color: #555; }
        .custom-table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        .custom-table th, .custom-table td { padding: 12px 15px; border-bottom: 1px solid #ddd; vertical-align: middle; }
        .custom-table th { background-color: #333; color: white; }
        .btn-delete { background-color: #dc3545; color: white; border: none; padding: 5px 10px; border-radius: 4px; }
        .nav-link.active { color: #d4af37; border-bottom: 3px solid #d4af37 !important; }
        
        .close-notif { 
            float: right; 
            cursor: pointer; 
            color: #0c5460; 
            font-weight: bold; 
            background: none; 
            border: none; 
            font-size: 1.2em;
            line-height: 1;
        }
        .close-notif:hover { color: red; }
    </style>
</head>
<body>

<div class="main-container">
    <a href="logout.php" class="btn btn-danger float-end mb-3">Kijelentkezés</a>
    <div style="clear: both;"></div>

    <h1>Vezérlőpult</h1>
    <p class="welcome">Üdvözöllek, <strong><?php echo $barber_name; ?></strong>!</p>

    <?php
    $sql_notif = "SELECT * FROM ertesitesek 
                  WHERE cimzett_id = $barber_id 
                  AND cimzett_tipus = 'fodrasz' 
                  AND olvasva = 0 
                  ORDER BY datum DESC LIMIT 5";
    $res_notif = $conn->query($sql_notif);

    if ($res_notif->num_rows > 0) {
        echo '<div class="alert alert-info shadow-sm">';
        echo '<h5 class="alert-heading">🔔 Értesítéseid:</h5>';
        echo '<ul class="mb-0 ps-3">';
        while ($notif = $res_notif->fetch_assoc()) {
            $time = date('Y.m.d H:i', strtotime($notif['datum']));
            $msg = htmlspecialchars($notif['uzenet']);
            $nid = $notif['id'];
            echo "<li id='notif-$nid' class='mb-2'>
                    <small class='text-muted'>$time</small> - <strong>$msg</strong>
                    <button class='close-notif' onclick='dismissNotif($nid)' title='Bezárás'>&times;</button>
                  </li>";
        }
        echo '</ul>';
        echo '</div>';
    }
    ?>

    <?php if (isset($_GET['msg']) && $_GET['msg'] == 'deleted_successfully'): ?>
        <div class="alert alert-success alert-dismissible fade show">Az időpontot sikeresen törölted!
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <ul class="nav nav-tabs" id="myTab" role="tablist">
        <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#upcoming-pane">Napi Teendők</button></li>
        <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#past-pane">Korábbi Foglalások</button></li>
    </ul>

    <div class="tab-content mt-3">
        <div class="tab-pane fade show active" id="upcoming-pane">
            <?php if ($result_upcoming->num_rows > 0): ?>
                <table class="custom-table">
                    <thead><tr><th>Dátum</th><th>Időpont</th><th>Vendég Neve</th><th>Vendég Email</th><th>Művelet</th></tr></thead>
                    <tbody>
                        <?php while($row = $result_upcoming->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo date('Y. m. d.', strtotime($row['Kezdes'])); ?></td>
                                <td><?php echo date('H:i', strtotime($row['Kezdes'])) . ' - ' . date('H:i', strtotime($row['Befejezes'])); ?></td>
                                <td><?php echo $row['Ugyfel_Nev']; ?></td>
                                <td><?php echo $row['Ugyfel_Email']; ?></td>
                                <td>
                                    <form action="barber_cancel_booking.php" method="POST" onsubmit="return confirm('Biztosan lemondod?');">
                                        <input type="hidden" name="booking_id" value="<?php echo $row['Idopont_ID']; ?>">
                                        <button type="submit" class="btn-delete">Lemondás</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p class="text-center text-muted mt-3">Nincs közelgő foglalásod.</p>
            <?php endif; ?>
        </div>

        <div class="tab-pane fade" id="past-pane">
            <?php if ($result_past->num_rows > 0): ?>
                <table class="custom-table text-muted">
                    <thead><tr><th>Dátum</th><th>Időpont</th><th>Vendég Neve</th><th>Vendég Email</th></tr></thead>
                    <tbody>
                        <?php while($row = $result_past->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo date('Y. m. d.', strtotime($row['Kezdes'])); ?></td>
                                <td><?php echo date('H:i', strtotime($row['Kezdes'])) . ' - ' . date('H:i', strtotime($row['Befejezes'])); ?></td>
                                <td><?php echo $row['Ugyfel_Nev']; ?></td>
                                <td><?php echo $row['Ugyfel_Email']; ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p class="text-center text-muted mt-3">Nincsenek korábbi foglalások.</p>
            <?php endif; ?>
        </div>
    </div> 
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<script>
    function dismissNotif(id) {
        fetch('mark_notification_read.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: id })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const el = document.getElementById('notif-' + id);
                if (el) el.style.display = 'none';
            } else {
                console.error("Hiba:", data.message);
            }
        })
        .catch(err => console.error(err));
    }
</script>

</body>
</html>
<?php $conn->close(); ?>