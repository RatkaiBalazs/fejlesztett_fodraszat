<?php
// Letiltjuk, hogy a PHP automatikusan HTML hibákat írjon ki a képernyőre
// Ez okozta a "<br /> <b>" hibát a Reactban!
error_reporting(0); 
mysqli_report(MYSQLI_REPORT_OFF);

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "barbershop";

// Megpróbálunk csatlakozni (a @ jel elnyomja a rendszerüzeneteket)
$conn = @new mysqli($servername, $username, $password, $dbname);

// Ha nem sikerült, JSON formátumban küldjük a hibát, és LEÁLLUNK
if ($conn->connect_error) {
    header("Content-Type: application/json");
    echo json_encode(["success" => false, "message" => "Adatbázis hiba: " . $conn->connect_error]);
    exit();
}

// Ha sikerült, beállítjuk az ékezeteket
$conn->set_charset("utf8");
?>