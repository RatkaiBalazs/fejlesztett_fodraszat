<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

require 'db.php';

$data = json_decode(file_get_contents("php://input"));

if (isset($data->id)) {
    $notif_id = (int)$data->id;

    // Beállítjuk az 'olvasva' értéket 1-re (így többé nem jelenik meg)
    $sql = "UPDATE ertesitesek SET olvasva = 1 WHERE id = $notif_id";

    if ($conn->query($sql) === TRUE) {
        echo json_encode(["success" => true]);
    } else {
        echo json_encode(["success" => false, "message" => $conn->error]);
    }
} else {
    echo json_encode(["success" => false, "message" => "Nincs ID"]);
}

$conn->close();
?>