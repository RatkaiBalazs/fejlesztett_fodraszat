<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require 'db.php';

$json = file_get_contents("php://input");
$data = json_decode($json);

if ($data === null || !isset($data->email)) {
    echo json_encode(["success" => false, "message" => "Hiányzó adatok!"]);
    exit();
}

$email = $conn->real_escape_string($data->email);

// 1. Megkeressük az ID-t
$sql_get_id = "SELECT Ugyfel_ID FROM Ugyfel WHERE Ugyfel_Email = '$email'";
$result = $conn->query($sql_get_id);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $user_id = $row['Ugyfel_ID'];

    // --- 1. LÉPÉS: Törlés a 'kapcsolotabla'-ból ---
    // Megkeressük azokat a kapcsoló sorokat, amik a felhasználó időpontjaihoz tartoznak
    $del_kapcsolo = "DELETE FROM kapcsolotabla WHERE Idopont_ID IN (SELECT Idopont_ID FROM idopont WHERE Ugyfel_ID = '$user_id')";
    
    if (!$conn->query($del_kapcsolo)) {
        echo json_encode(["success" => false, "message" => "Hiba a kapcsolótábla törlésekor: " . $conn->error]);
        exit();
    }

    // --- 2. LÉPÉS: Törlés az 'idopont' táblából ---
    // Most már törölhetjük az időpontokat, mert nincs rájuk hivatkozás
    $del_appointments = "DELETE FROM idopont WHERE Ugyfel_ID = '$user_id'";
    
    if (!$conn->query($del_appointments)) {
        echo json_encode(["success" => false, "message" => "Hiba az időpontok törlésekor: " . $conn->error]);
        exit();
    }

    // --- 3. LÉPÉS: Törlés az 'Ugyfel' táblából ---
    // Végül töröljük magát a felhasználót
    $sql_delete_user = "DELETE FROM Ugyfel WHERE Ugyfel_ID = '$user_id'";

    if ($conn->query($sql_delete_user) === TRUE) {
        echo json_encode(["success" => true, "message" => "Fiók sikeresen törölve."]);
    } else {
        echo json_encode(["success" => false, "message" => "Hiba a felhasználó törlésekor: " . $conn->error]);
    }

} else {
    echo json_encode(["success" => false, "message" => "Felhasználó nem található."]);
}

$conn->close();
?>