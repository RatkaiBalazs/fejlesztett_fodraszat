<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

require 'db.php';

$data = json_decode(file_get_contents("php://input"));

// Ellenőrizzük, hogy kaptunk-e ID-t
if (!isset($data->id)) {
    echo json_encode(["success" => false, "message" => "Nincs ID megadva!"]);
    exit();
}

$booking_id = (int)$data->id;

// --- 1. ADATOK LEKÉRÉSE ---
// Fontos: Most már lekérjük a 'letrehozas_datum'-ot is!
$sql_info = "SELECT fodraszok.Fodrasz_ID, ugyfel.Ugyfel_Nev, idopont.Kezdes, idopont.letrehozas_datum 
             FROM idopont 
             JOIN fodraszok ON idopont.Fodrasz_ID = fodraszok.Fodrasz_ID
             JOIN ugyfel ON idopont.Ugyfel_ID = ugyfel.Ugyfel_ID
             WHERE Idopont_ID = $booking_id";

$res = $conn->query($sql_info);

if ($res->num_rows > 0) {
    $row = $res->fetch_assoc();
    
    $fodrasz_id = $row['Fodrasz_ID'];
    $vendeg_nev = $row['Ugyfel_Nev'];
    $idopont_str = $row['Kezdes'];
    $letrehozas_str = $row['letrehozas_datum'];

    // --- IDŐSZÁMÍTÁS ---
    $most = time(); // Jelenlegi idő (másodpercben)
    $idopont_timestamp = strtotime($idopont_str); // Mikor lesz a hajvágás?
    $letrehozas_timestamp = strtotime($letrehozas_str); // Mikor kattintott a foglalásra?

    // Ha régi az adatbázis és nincs létrehozási dátum (NULL), akkor 0-nak vesszük
    if (!$letrehozas_timestamp) { $letrehozas_timestamp = 0; }

    // Kiszámoljuk a különbségeket
    $elmult_percek = ($most - $letrehozas_timestamp) / 60; // Hány perce foglalták?
    $hatralevo_orak = ($idopont_timestamp - $most) / 3600; // Hány óra van a vágásig?


    // --- DÖNTÉSI LOGIKA ---

    // A) 5 PERCES SZABÁLY (Téves foglalás korrigálása)
    // Ha 5 percen belül vagyunk a foglalás óta -> Törlés szó nélkül (Nincs értesítés)
    if ($elmult_percek <= 5 && $letrehozas_timestamp > 0) {
        
        // Törlés a kapcsolótáblából
        $conn->query("DELETE FROM KapcsoloTabla WHERE Idopont_ID = $booking_id");
        // Törlés az időpontból
        $conn->query("DELETE FROM Idopont WHERE Idopont_ID = $booking_id");

        echo json_encode(["success" => true, "message" => "Téves foglalás törölve."]);
        exit(); // Itt megállunk, nem fut tovább a kód
    }

    // B) 24 ÓRÁS SZABÁLY (Túl késői lemondás)
    // Ha kevesebb mint 24 óra van hátra -> HIBA, nem törlünk!
    if ($hatralevo_orak < 24) {
        echo json_encode([
            "success" => false, 
            "message" => "Sajnáljuk, 24 órán belül már nem mondhatod le az időpontot online! Kérjük, hívd fel a fodrászt."
        ]);
        exit(); // Itt megállunk, nem törlünk semmit
    }

    // C) NORMÁL ESET (Szabályos lemondás)
    // Ha több mint 5 perce foglalta ÉS még több mint 24 óra van hátra -> Törlés + Értesítés

    // 1. Értesítés beírása
    $uzenet = "$vendeg_nev lemondta a $idopont_str időpontot.";
    $sql_notify = "INSERT INTO ertesitesek (cimzett_id, cimzett_tipus, uzenet) 
                   VALUES ($fodrasz_id, 'fodrasz', '$uzenet')";
    $conn->query($sql_notify);

    // 2. Törlés végrehajtása
    $conn->query("DELETE FROM KapcsoloTabla WHERE Idopont_ID = $booking_id");
    
    if ($conn->query("DELETE FROM Idopont WHERE Idopont_ID = $booking_id") === TRUE) {
        echo json_encode(["success" => true, "message" => "Sikeres lemondás, a fodrász értesítve lett!"]);
    } else {
        echo json_encode(["success" => false, "message" => "Hiba a törléskor: " . $conn->error]);
    }

} else {
    // Ha nem találtuk meg az ID-t
    echo json_encode(["success" => false, "message" => "Nem található ilyen időpont, talán már törölték."]);
}

$conn->close();
?>