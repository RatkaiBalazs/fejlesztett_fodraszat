<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

require 'db.php';

// A beérkező JSON adat olvasása (React ezt küldi)
$data = json_decode(file_get_contents("php://input"));

// Ellenőrizzük, hogy kaptunk-e ID-t
if (!isset($data->id)) {
    echo json_encode(["success" => false, "message" => "Nincs ID megadva!"]);
    exit();
}

$id = $data->id;

// 1. Töröljük a kapcsolatot a KapcsoloTabla-ból (Biztonsági lépés)
$sql_link = "DELETE FROM KapcsoloTabla WHERE Idopont_ID = $id";
$conn->query($sql_link);

// 2. Töröljük magát az Időpontot
$sql = "DELETE FROM Idopont WHERE Idopont_ID = $id";

if ($conn->query($sql) === TRUE) {
    echo json_encode(["success" => true, "message" => "Sikeres törlés!"]);
} else {
    echo json_encode(["success" => false, "message" => "Hiba a törléskor: " . $conn->error]);
}

$conn->close();
?>