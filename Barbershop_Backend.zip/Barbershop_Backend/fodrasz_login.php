<?php
session_start();

// Ha kijelentkezésre kattintottak a dashboardon
if (isset($_GET['logout'])) {
    session_destroy();
    unset($_SESSION['user_id']);
    header("Location: login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "barbershop");

if (isset($_POST['login_gomb'])) {
    $nev = $_POST['nev'];
    $jelszo = $_POST['jelszo']; 

    // Megnézzük a "fodraszok" táblában, hogy egyezik-e a név és jelszó
    // FONTOS: Győződj meg róla, hogy a 'jelszo' oszlop létezik a tábládban!
    $sql = "SELECT * FROM fodraszok WHERE Fodrasz_Nev = '$nev' AND jelszo = '$jelszo'";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        $sor = $result->fetch_assoc();
        
        // Siker! Elmentjük, ki ő, és átküldjük a dashboardra
        $_SESSION['user_id'] = $sor['Fodrasz_ID'];
        header("Location: dashboard.php");
        exit();
    } else {
        $hiba = "Hibás név vagy jelszó!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Belépés</title>
</head>
<body>
    <h2>Fodrász Belépés</h2>
    <?php if(isset($hiba)) echo "<p style='color:red'>$hiba</p>"; ?>
    
    <form method="post">
        Név: <input type="text" name="nev" required><br><br>
        Jelszó: <input type="password" name="jelszo" required><br><br>
        <button type="submit" name="login_gomb">Belépés</button>
    </form>
</body>
</html>