<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

require 'db.php';

$input = json_decode(file_get_contents("php://input"), true);

if (!isset($input['user_id']) || !isset($input['fodrasz_nev']) || !isset($input['rating']) || !isset($input['comment'])) {
    echo json_encode(['success' => false, 'message' => 'Hiányzó adatok!']);
    exit();
}

$user_id = (int)$input['user_id'];
$fodrasz_nev = $conn->real_escape_string($input['fodrasz_nev']);
$rating = (int)$input['rating'];
$comment = $conn->real_escape_string($input['comment']);

// BEILLESZTÉS A TE TÁBLÁDBA:
// Fodrasz_Neve, Szoveges_velemeny, Ertekeles
$sql = "INSERT INTO velemenyek (Ugyfel_ID, Fodrasz_Neve, Ertekeles, Szoveges_velemeny) 
        VALUES ('$user_id', '$fodrasz_nev', '$rating', '$comment')";

if ($conn->query($sql)) {
    echo json_encode(['success' => true, 'message' => 'Köszönjük a véleményed!']);
} else {
    echo json_encode(['success' => false, 'message' => 'Hiba történt: ' . $conn->error]);
}
?>