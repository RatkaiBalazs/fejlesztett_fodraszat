<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

require 'db.php';

if (!isset($_GET['barber_name'])) {
    echo json_encode([]);
    exit();
}

$barberName = $conn->real_escape_string($_GET['barber_name']);

$sql = "SELECT 
            i.Idopont_ID,
            i.Datum,
            i.Kezdes,
            u.Ugyfel_Nev AS Vendeg_Nev,      -- Javítva: Ugyfel_Nev
            u.Ugyfel_Telszam AS Vendeg_Tel,  -- Javítva: Ugyfel_Telszam
            sz.Szolgaltatas_Nev
        FROM Idopont i
        JOIN KapcsoloTabla k ON i.Idopont_ID = k.Idopont_ID
        -- Itt feltételezem, hogy a KapcsoloTabla-ban 'Felhasznalo_ID' a neve, de az az 'ugyfel' tábla 'Ugyfel_ID'-jére mutat
        JOIN ugyfel u ON k.Felhasznalo_ID = u.Ugyfel_ID 
        JOIN Alkalmazott a ON k.Alkalmazott_ID = a.Alkalmazott_ID
        JOIN Szolgaltatas sz ON k.Szolgaltatas_ID = sz.Szolgaltatas_ID
        WHERE a.Nev LIKE '%$barberName%' 
        ORDER BY i.Datum ASC, i.Kezdes ASC";

$result = $conn->query($sql);
$bookings = [];

if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $bookings[] = $row;
    }
}

echo json_encode($bookings);
$conn->close();
?>