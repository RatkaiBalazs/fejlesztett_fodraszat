<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

require 'db.php';

// 1. Biztosítjuk a magyar időzónát
date_default_timezone_set('Europe/Budapest');

if (!isset($_GET['barber_name'])) {
    echo json_encode(['active' => [], 'past' => []]);
    exit();
}

$barberName = $conn->real_escape_string($_GET['barber_name']);

$sql = "SELECT 
            i.Idopont_ID,
            i.Datum,
            i.Kezdes,
            i.Befejezes, 
            u.Ugyfel_Nev AS Vendeg_Nev,
            u.Ugyfel_Telszam AS Vendeg_Tel,
            sz.Szolgaltatas_Nev
        FROM Idopont i
        JOIN KapcsoloTabla k ON i.Idopont_ID = k.Idopont_ID
        JOIN ugyfel u ON i.Ugyfel_ID = u.Ugyfel_ID 
        JOIN Alkalmazott a ON i.Fodrasz_ID = a.Alkalmazott_ID
        JOIN Szolgaltatas sz ON k.Szolgaltatas_ID = sz.Szolgaltatas_ID
        WHERE a.Nev LIKE '%$barberName%' 
        ORDER BY i.Kezdes ASC"; 

$result = $conn->query($sql);

$active_bookings = [];
$past_bookings = [];

// 2. Lekérjük a pontos időt másodpercben (számként)
$current_timestamp = time(); 

if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        
        // 3. A foglalás kezdését is átalakítjuk számmá
        $booking_start_ts = strtotime($row['Kezdes']);

        // 4. MATEMATIKAI ÖSSZEHASONLÍTÁS
        // Ha a kezdés száma kisebb, mint a mostani idő száma -> ELMÚLT
        if ($booking_start_ts < $current_timestamp) {
            $past_bookings[] = $row;
        } else {
            $active_bookings[] = $row;
        }
    }
}

echo json_encode([
    'active' => $active_bookings,
    'past' => $past_bookings,
    'server_time' => date('Y-m-d H:i:s', $current_timestamp) // Debug: visszaküldjük a szerver idejét is
]);

$conn->close();
?>