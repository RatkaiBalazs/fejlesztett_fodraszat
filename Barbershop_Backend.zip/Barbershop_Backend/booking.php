<?php
// ==========================================
// 1. BEÁLLÍTÁSOK ÉS KAPCSOLÓDÁS
// ==========================================

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

date_default_timezone_set('Europe/Budapest');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

$closing_hours = [
    1 => '20:00', // Hétfő
    2 => '20:00', // Kedd
    3 => '20:00', // Szerda
    4 => '20:00', // Csütörtök
    5 => '20:00', // Péntek
    6 => '16:00', // Szombat
    0 => null     // Vasárnap (Zárva)
];

$host = 'localhost';
$db   = 'barbershop';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Adatbázis hiba: ' . $e->getMessage()]);
    exit();
}

// ==========================================
// 2. ADATOK FOGADÁSA REACTBŐL
// ==========================================

$input = json_decode(file_get_contents("php://input"), true);

if (!isset($input['service_id']) || !isset($input['date']) || !isset($input['time']) || !isset($input['employee_id']) || !isset($input['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Hiányzó adatok a foglaláshoz!']);
    exit();
}

$service_id = $input['service_id'];
$employee_id = $input['employee_id'];
$user_id = $input['user_id'];
$date_str = $input['date'];
$time_str = $input['time'];

// --- 🛑 ÚJ VÉDELEM: Csak 30 perces (egész/fél) időközök engedélyezése 🛑 ---
$timestamp_check = strtotime("$date_str $time_str");
$minutes = (int)date('i', $timestamp_check);

// Ha a perc nem osztható 30-cal (tehát nem 00 vagy 30)
if ($minutes % 30 !== 0) {
    echo json_encode([
        'success' => false, 
        'message' => 'Hiba: Csak egész (00) és fél (30) órás időpontokra lehet foglalni! A ' . $time_str . ' érvénytelen.'
    ]);
    exit();
}
// ------------------------------------------------------------------

// ==========================================
// 3. LOGIKA ÉS ELLENŐRZÉSEK
// ==========================================

$stmt_duration = $pdo->prepare("SELECT Szolgaltatas_Ido FROM Szolgaltatas WHERE Szolgaltatas_ID = ?");
$stmt_duration->execute([$service_id]);
$service_data = $stmt_duration->fetch();

if (!$service_data) {
    echo json_encode(['success' => false, 'message' => 'A kiválasztott szolgáltatás nem található.']);
    exit();
}

$duration_minutes = $service_data['Szolgaltatas_Ido'];

try {
    $start_datetime = new DateTime($date_str . ' ' . $time_str);
    $end_datetime = clone $start_datetime;
    $end_datetime->modify('+' . $duration_minutes . ' minutes');

    $start_timestamp = $start_datetime->format('Y-m-d H:i:s');
    $end_timestamp = $end_datetime->format('Y-m-d H:i:s');
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Hibás dátum formátum.']);
    exit();
}

$day_of_week = $start_datetime->format('w'); 

if (!isset($closing_hours[$day_of_week]) || $closing_hours[$day_of_week] === null) {
    echo json_encode(['success' => false, 'message' => 'Ezen a napon sajnos zárva vagyunk.']);
    exit();
}

$closing_time_str = $closing_hours[$day_of_week]; 
$closing_datetime = new DateTime($date_str . ' ' . $closing_time_str);

if ($end_datetime > $closing_datetime) {
    echo json_encode([
        'success' => false, 
        'message' => 'Ez a szolgáltatás (' . $duration_minutes . ' perc) már túllógna a záráson (' . $closing_time_str . ').'
    ]);
    exit();
}

$sql_check = "
    SELECT Idopont_ID 
    FROM Idopont 
    WHERE Fodrasz_ID = ?
      AND (
            (Kezdes < ? AND Befejezes > ?) 
          )
    LIMIT 1;
";

$stmt_check = $pdo->prepare($sql_check);
$stmt_check->execute([$employee_id, $end_timestamp, $start_timestamp]);
$existing_appointment = $stmt_check->fetch();

if ($existing_appointment) {
    echo json_encode(['success' => false, 'message' => 'Ez az időpont sajnos közben betelt (vagy ütközik)!']);
    exit();
}

// ==========================================
// 4. MENTÉS AZ ADATBÁZISBA
// ==========================================

try {
    $pdo->beginTransaction();

    $sql_insert = "
        INSERT INTO Idopont (Ugyfel_ID, Fodrasz_ID, Kezdes, Befejezes, Statusz)
        VALUES (?, ?, ?, ?, 'F')
    ";
    
    $stmt_insert = $pdo->prepare($sql_insert);
    $stmt_insert->execute([$user_id, $employee_id, $start_timestamp, $end_timestamp]);
    
    $new_appointment_id = $pdo->lastInsertId();

    $sql_link = "INSERT INTO KapcsoloTabla (Idopont_ID, Szolgaltatas_ID) VALUES (?, ?)";
    $stmt_link = $pdo->prepare($sql_link);
    $stmt_link->execute([$new_appointment_id, $service_id]);

    $pdo->commit();

    echo json_encode(['success' => true, 'message' => 'Sikeres foglalás!']);

} catch (Exception $e) {
    $pdo->rollBack();
    echo json_encode(['success' => false, 'message' => 'Hiba történt a mentéskor: ' . $e->getMessage()]);
}
?>