<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

require 'db.php';

// Megnézzük, hogy küldtek-e user_id-t (ki van-e lépve a felhasználó)
if (!isset($_GET['user_id'])) {
    echo json_encode(["success" => false, "message" => "Nincs megadva felhasználó!"]);
    exit();
}

$user_id = $_GET['user_id'];

// SQL: Lekérjük az időpontot, a fodrász nevét és a szolgáltatás nevét
// Mivel van Kapcsolótábla, azon keresztül kell összekötni őket
$sql = "SELECT 
            i.Idopont_ID, 
            i.Kezdes, 
            f.Fodrasz_Nev, 
            s.Szolgaltatas_Nev
        FROM Idopont i
        JOIN Fodraszok f ON i.Fodrasz_ID = f.Fodrasz_ID
        LEFT JOIN KapcsoloTabla k ON i.Idopont_ID = k.Idopont_ID
        LEFT JOIN Szolgaltatas s ON k.Szolgaltatas_ID = s.Szolgaltatas_ID
        WHERE i.Ugyfel_ID = '$user_id'
        ORDER BY i.Kezdes ASC"; // Időrendi sorrend

$result = $conn->query($sql);

$bookings = [];

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $bookings[] = $row;
    }
}

echo json_encode($bookings);

$conn->close();
?>