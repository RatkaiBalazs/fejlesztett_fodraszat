<?php
session_start();

// Adatbázis kapcsolat
$conn = new mysqli("localhost", "root", "", "barbershop");
$conn->set_charset("utf8");

if ($conn->connect_error) {
    die("Kapcsolódási hiba: " . $conn->connect_error);
}

// Biztonsági ellenőrzés
if (!isset($_SESSION['user_id'])) {
    die("Hiba: Nem vagy bejelentkezve.");
}

$barber_id = $_SESSION['user_id'];

// ITT A JAVÍTÁS: Nem JSON-t olvasunk, hanem a $_POST tömböt nézzük!
if (isset($_POST['booking_id'])) {
    $booking_id = (int)$_POST['booking_id'];

    // --- 1. LÉPÉS: ADATOK LEKÉRÉSE AZ ÉRTESÍTÉSHEZ ---
    // Megnézzük, ki volt a vendég, hogy írhassunk neki
    $sql_info = "SELECT ugyfel.Ugyfel_ID, idopont.Kezdes 
                 FROM idopont 
                 JOIN ugyfel ON idopont.Ugyfel_ID = ugyfel.Ugyfel_ID 
                 WHERE idopont.Idopont_ID = $booking_id AND idopont.Fodrasz_ID = $barber_id";
    
    $res = $conn->query($sql_info);
    
    if ($res->num_rows > 0) {
        $row = $res->fetch_assoc();
        $ugyfel_id = $row['Ugyfel_ID'];
        $datum = $row['Kezdes'];
        
        // --- 2. LÉPÉS: ÉRTESÍTÉS LÉTREHOZÁSA A VENDÉGNEK ---
        // A cimzett_tipus 'ugyfel', mert a fodrász mondta le
        $uzenet = "Sajnáljuk, a fodrász lemondta a $datum időpontodat.";
        $sql_notify = "INSERT INTO ertesitesek (cimzett_id, cimzett_tipus, uzenet) 
                       VALUES ($ugyfel_id, 'ugyfel', '$uzenet')";
        $conn->query($sql_notify);
    }

    // --- 3. LÉPÉS: TÖRLÉS (Először a kapcsolótábla, aztán az időpont) ---
    $conn->query("DELETE FROM kapcsolotabla WHERE Idopont_ID = $booking_id");
    
    $sql_del = "DELETE FROM idopont WHERE Idopont_ID = $booking_id AND Fodrasz_ID = $barber_id";

    if ($conn->query($sql_del) === TRUE) {
        // Siker esetén visszairányítunk a vezérlőpultra
        header("Location: dashboard.php?msg=deleted_successfully");
        exit();
    } else {
        echo "Hiba a törlés során: " . $conn->error;
    }

} else {
    // Ha nem jött ID, visszadobjuk a dashboardra
    header("Location: dashboard.php");
    exit();
}

$conn->close();
?>