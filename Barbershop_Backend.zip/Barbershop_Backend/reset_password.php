<?php
// 1. CORS és PREFLIGHT KEZELÉS
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// 2. ADATBÁZIS BETÖLTÉSE
require 'db.php';

// 3. ADATOK FELDOLGOZÁSA
$json = file_get_contents("php://input");
$data = json_decode($json);

if ($data === null) {
    echo json_encode(["success" => false, "message" => "Nem érkezett adat (JSON hiba)!"]);
    exit();
}

if (!isset($data->email) || !isset($data->phone) || !isset($data->new_password)) {
    echo json_encode(["success" => false, "message" => "Kérjük, tölts ki minden mezőt!"]);
    exit();
}

$email = $conn->real_escape_string($data->email);
$phone = $conn->real_escape_string($data->phone);
$new_pass = $conn->real_escape_string($data->new_password);

// 4. LOGIKA: Felhasználó keresése (ITT VOLT A HIBA)
// Javítva: Ugyfel_Tel -> Ugyfel_Telszam
$sql_check = "SELECT Ugyfel_ID FROM Ugyfel WHERE Ugyfel_Email = '$email' AND Ugyfel_Telszam = '$phone'";
$result = $conn->query($sql_check);

if (!$result) {
    echo json_encode(["success" => false, "message" => "SQL Hiba: " . $conn->error]);
    exit();
}

if ($result->num_rows > 0) {
    // Találtunk ilyen embert -> Jelszó frissítése
    // Javítva: A jelszo2-t is frissítjük, hogy megfeleljen a CONSTRAINT szabálynak!
$sql_update = "UPDATE Ugyfel SET Ugyfel_jelszo1 = '$new_pass', Ugyfel_jelszo2 = '$new_pass' WHERE Ugyfel_Email = '$email'";
    if ($conn->query($sql_update) === TRUE) {
        echo json_encode(["success" => true, "message" => "Sikeres jelszócsere!"]);
    } else {
        echo json_encode(["success" => false, "message" => "Hiba a mentéskor: " . $conn->error]);
    }
} else {
    echo json_encode(["success" => false, "message" => "Hibás email vagy telefonszám! (Ellenőrizd, hogy pontosan adtad-e meg)"]);
}

$conn->close();
?>