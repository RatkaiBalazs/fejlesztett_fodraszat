<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

require 'db.php';

$data = json_decode(file_get_contents("php://input"));

// Ellenőrizzük, hogy a kötelező adatok megjöttek-e
if (!isset($data->name) || !isset($data->email) || !isset($data->password)) {
    echo json_encode(["success" => false, "message" => "Hiányzó adatok!"]);
    exit();
}

$name = $conn->real_escape_string($data->name);
$email = $conn->real_escape_string($data->email);
$phone = isset($data->phone) ? $conn->real_escape_string($data->phone) : ''; 
$password = $conn->real_escape_string($data->password); 

// Megnézzük, van-e már ilyen email
$checkEmail = "SELECT * FROM ugyfel WHERE Ugyfel_Email='$email'";
if ($conn->query($checkEmail)->num_rows > 0) {
    echo json_encode(["success" => false, "message" => "Ez az email cím már foglalt!"]);
    exit();
}

// --- TISZTÍTÁS KÉSZ ---
// Kivettük a Szerepkor oszlopot az utasításból.
// Csak a nevet, emailt, telefont és jelszót mentjük.
$sql = "INSERT INTO ugyfel (Ugyfel_Nev, Ugyfel_Email, Ugyfel_Telszam, Ugyfel_jelszo1, Ugyfel_jelszo2) 
        VALUES ('$name', '$email', '$phone', '$password', '$password')";

if ($conn->query($sql) === TRUE) {
    echo json_encode(["success" => true, "message" => "Sikeres regisztráció!"]);
} else {
    echo json_encode(["success" => false, "message" => "Hiba: " . $conn->error]);
}

$conn->close();
?>