import React, { useState, useEffect } from 'react';
import './AuthModal.css'; // Ugyanazt a stílust használjuk, mint a bejelentkezésnél!

const ProfileModal = ({ onClose }) => {
  const [user, setUser] = useState(null);
  const [newPhone, setNewPhone] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  // 1. Betöltjük a jelenlegi adatokat
  useEffect(() => {
    const storedUser = JSON.parse(localStorage.getItem('user'));
    if (storedUser) {
      setUser(storedUser);
      setNewPhone(storedUser.phone || storedUser.Ugyfel_Telszam || ''); 
    }
  }, []);

  // --- TELEFONSZÁM MÓDOSÍTÁSA ---
  const handleUpdate = async (e) => {
    e.preventDefault();
    setMessage('');
    setError('');

    if (!user) return;

    try {
      const response = await fetch('http://localhost/Barbershop_Backend/update_phone.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
            email: user.email || user.Ugyfel_Email, 
            new_phone: newPhone 
        }),
      });

      const data = await response.json();

      if (data.success) {
        setMessage(data.message);
        
        // Frissítjük a localStorage-t
        const updatedUser = { ...user, phone: newPhone, Ugyfel_Telszam: newPhone };
        localStorage.setItem('user', JSON.stringify(updatedUser));
        
        setTimeout(() => {
            onClose();
            window.location.reload(); 
        }, 1500);

      } else {
        setError(data.message);
      }
    } catch (err) {
      console.error(err);
      setError('Nem sikerült elérni a szervert.');
    }
  };

  // --- ÚJ RÉSZ: FIÓK TÖRLÉSE ---
  const handleDelete = async () => {
    // Biztonsági kérdés
    if (!window.confirm("BIZTOSAN törölni szeretnéd a fiókodat? Ez a lépés nem visszavonható, és minden foglalásod elveszik!")) {
      return;
    }

    try {
      const response = await fetch('http://localhost/Barbershop_Backend/delete_profile.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: user.email || user.Ugyfel_Email }),
      });

      const data = await response.json();

      if (data.success) {
        alert("A fiókodat töröltük. Viszlát! 👋");
        localStorage.removeItem('user'); // Kijelentkeztetés
        window.location.reload(); // Frissítés, hogy eltűnjön a menü
      } else {
        setError(data.message);
      }
    } catch (err) {
      console.error(err);
      setError('Nem sikerült elérni a szervert (Törlés hiba).');
    }
  };

  if (!user) return null;

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <button className="close-btn" onClick={onClose}>&times;</button>
        
        <h2>Profil Szerkesztése</h2>
        
        <p style={{marginBottom: '20px'}}>
            Jelenlegi felhasználó: <strong>{user.name || user.Ugyfel_Nev}</strong>
        </p>

        {/* Ha van a CSS-ben .success-message osztály, használd azt a style helyett! */}
        {message && <div className="success-message" style={{backgroundColor: '#d4edda', color: '#155724', padding: '10px', marginBottom: '10px', borderRadius: '5px'}}>{message}</div>}
        {error && <div className="error-message">{error}</div>}

        <form className="auth-form" onSubmit={handleUpdate}>
          <div className="form-group">
            <label>Új telefonszám</label>
            <input 
              type="tel" 
              value={newPhone} 
              onChange={(e) => setNewPhone(e.target.value)} 
              placeholder="+36 30 123 4567"
              required 
            />
          </div>

          <button type="submit" className="login-btn">Mentés</button>

          {/* --- ELVÁLASZTÓ VONAL --- */}
          <hr style={{ margin: '20px 0', border: '0', borderTop: '1px solid #ddd' }} />

          {/* --- PIROS TÖRLÉS GOMB --- */}
          <button 
            type="button" // FONTOS: type="button", különben elküldi a formot!
            onClick={handleDelete} 
            className="delete-btn"
            style={{
                width: '100%',
                padding: '10px',
                backgroundColor: '#dc3545', 
                color: 'white',
                border: 'none',
                borderRadius: '5px',
                cursor: 'pointer',
                fontWeight: 'bold',
                marginTop: '5px'
            }}
          >
            Fiók törlése 🗑️
          </button>

        </form>
      </div>
    </div>
  );
};

export default ProfileModal;