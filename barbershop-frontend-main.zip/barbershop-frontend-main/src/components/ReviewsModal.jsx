import React, { useState, useEffect } from 'react';
import './ReviewsModal.css'; 

const ReviewsModal = ({ barber, onClose, user }) => {
  const [reviews, setReviews] = useState([]);
  const [newRating, setNewRating] = useState(5);
  const [newComment, setNewComment] = useState("");

  useEffect(() => {
    fetch(`http://localhost/Barbershop_Backend/get_reviews.php?fodrasz_nev=${encodeURIComponent(barber.name)}`)
      .then(res => res.json())
      .then(data => setReviews(data))
      .catch(err => console.error(err));
  }, [barber.name]);

  const handleSubmit = async () => {
    if (!user) {
        alert("Vélemény írásához be kell jelentkezned!");
        return;
    }
    
    // --- MÓDOSÍTÁS: Kivettük a kötelező szöveg ellenőrzést ---
    // if (!newComment) { alert(...) } <--- EZT TÖRÖLTÜK
    
    const payload = {
        user_id: user.id || user.Ugyfel_ID,
        fodrasz_nev: barber.name,
        rating: newRating,
        comment: newComment // Ez lehet üres string is mostantól
    };

    try {
        const res = await fetch('http://localhost/Barbershop_Backend/submit_review.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(payload)
        });
        const data = await res.json();
        if (data.success) {
            alert("Köszönjük az értékelést!");
            setNewComment("");
            setNewRating(5);
            // Lista frissítése
            fetch(`http://localhost/Barbershop_Backend/get_reviews.php?fodrasz_nev=${encodeURIComponent(barber.name)}`)
                .then(res => res.json())
                .then(d => setReviews(d));
        } else {
            alert(data.message);
        }
    } catch (error) {
        console.error("Hiba:", error);
    }
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content reviews-modal" onClick={e => e.stopPropagation()}>
        <button className="close-btn" onClick={onClose}>&times;</button>
        
        <h3>Vélemények: {barber.name}</h3>

        <div className="reviews-list">
            {reviews.length === 0 ? <p>Még nem érkezett vélemény.</p> : null}
            {reviews.map((rev, index) => (
                <div key={index} className="review-card">
                    <div className="review-header">
                        <strong>{rev.Ugyfel_Nev || "Vendég"}</strong>
                        <span className="stars">{"★".repeat(rev.Ertekeles)}{"☆".repeat(5 - rev.Ertekeles)}</span>
                    </div>
                    {/* Ha nincs szöveg, ne jelenjen meg üres sor */}
                    {rev.Szoveges_velemeny && <p className="review-text">{rev.Szoveges_velemeny}</p>}
                    <small className="review-date">{rev.Datum}</small>
                </div>
            ))}
        </div>

        <div className="write-review">
            <h4>Írj véleményt!</h4>
            <div className="rating-select">
                {[1, 2, 3, 4, 5].map(star => (
                    <span 
                        key={star} 
                        className={star <= newRating ? "star active" : "star"}
                        onClick={() => setNewRating(star)}
                    >★</span>
                ))}
            </div>
            <textarea 
                placeholder="Írd le a tapasztalataidat (opcionális)..." 
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
            />
            <button className="submit-review-btn" onClick={handleSubmit}>Beküldés</button>
        </div>

      </div>
    </div>
  );
};

export default ReviewsModal;