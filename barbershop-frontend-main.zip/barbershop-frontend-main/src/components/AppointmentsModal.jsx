import React, { useState, useEffect } from 'react';
import './AuthModal.css'; 
import './AppointmentsModal.css';

const AppointmentsModal = ({ onClose }) => {
  const [slots, setSlots] = useState([]);
  const [loading, setLoading] = useState(true);

  // --- ÁLLAPOTOK A FOGLALÁSHOZ ---
  const [step, setStep] = useState(1); // 1: Lista nézet, 2: Megerősítés
  const [selectedSlot, setSelectedSlot] = useState(null); 
  const [selectedService, setSelectedService] = useState(''); 

  // --- SZOLGÁLTATÁS LISTA (A KÉPED ALAPJÁN FRISSÍTVE) ---
  // Pontosan ezek vannak az adatbázisodban:
  const services = [
    { id: 1, name: "Hajvágás" },
    { id: 2, name: "Szakáll vágás" },
    { id: 3, name: "Szakáll + Hajvágás" },
    { id: 4, name: "Hajfestés" },
    { id: 5, name: "Igazítás" }
  ];

  const dayMap = {
    'Monday': 'Hétfő', 'Tuesday': 'Kedd', 'Wednesday': 'Szerda',
    'Thursday': 'Csütörtök', 'Friday': 'Péntek', 'Saturday': 'Szombat', 'Sunday': 'Vasárnap'
  };

  // --- 1. IDŐPONTOK BETÖLTÉSE ---
  useEffect(() => {
    fetch('http://localhost/Barbershop_Backend/get_slots.php')
      .then(res => res.json())
      .then(data => {
        setSlots(data);
        setLoading(false);
      })
      .catch(err => {
        console.error(err);
        setLoading(false);
      });
  }, []);

  // --- KATTINTÁS EGY IDŐPONTRA ---
  const handleSlotClick = (slot) => {
    const storedUser = localStorage.getItem('user');
    if (!storedUser) {
        alert("A foglaláshoz előbb be kell jelentkezned!");
        return;
    }
    
    setSelectedSlot(slot);
    setStep(2);
    setSelectedService(''); 
  };

  // --- VISSZA GOMB ---
  const handleBack = () => {
    setStep(1);
    setSelectedSlot(null);
  };

  // --- FOGLALÁS VÉGLEGESÍTÉSE ---
  const handleFinalizeBooking = async () => {
    if (!selectedService) {
        alert("Kérlek válassz egy szolgáltatást!");
        return;
    }

    const user = JSON.parse(localStorage.getItem('user'));
    const userId = user.id || user.Ugyfel_ID;

    // --- ITT A JAVÍTÁS A DÁTUMHOZ! ---
    // A Reactban "2024.05.20" van, de a PHP "2024-05-20"-at vár.
    // A .replace(/\./g, '-') kicseréli az összes pontot kötőjelre.
    const formattedDate = selectedSlot.date.replace(/\./g, '-');

    try {
        const response = await fetch('http://localhost/Barbershop_Backend/booking.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                user_id: userId,
                employee_id: selectedSlot.barber_id, 
                date: formattedDate, // <--- Itt küldjük a javított dátumot!
                time: selectedSlot.time,
                service_id: selectedService 
            })
        });

        const data = await response.json();

        if (data.success) {
            alert("✅ " + data.message);
            onClose(); 
            window.location.reload(); 
        } else {
            alert("❌ Hiba: " + data.message);
        }

    } catch (error) {
        console.error("Hiba:", error);
        alert("Szerver hiba történt.");
    }
  };

  // Csoportosítás dátum szerint
  const groupedSlots = slots.reduce((acc, slot) => {
    if (!acc[slot.date]) acc[slot.date] = [];
    acc[slot.date].push(slot);
    return acc;
  }, {});

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content appointments-modal-content" onClick={(e) => e.stopPropagation()}>
        
        <button className="close-btn" onClick={onClose}>&times;</button>
        
        {/* --- 1. LÉPÉS: LISTA --- */}
        {step === 1 && (
            <>
                <h2 style={{textAlign: 'center', marginBottom: '10px', color: '#333'}}>📅 Szabad Időpontok</h2>
                <p style={{textAlign: 'center', color: '#666', marginBottom: '20px'}}>
                    Kattints egy időpontra a foglaláshoz!
                </p>
                
                {loading ? (
                    <div className="loading-text" style={{color: '#333'}}>Betöltés folyamatban...</div>
                ) : (
                    <div className="slots-wrapper">
                        {Object.keys(groupedSlots).length === 0 ? (
                            <div className="empty-text" style={{color: '#333'}}>Sajnos nincs szabad hely. 😔</div>
                        ) : (
                            Object.keys(groupedSlots).map(date => (
                                <div key={date} className="date-group">
                                    <div className="date-title" style={{color: '#333'}}>
                                        {date} <span className="day-name">{dayMap[groupedSlots[date][0].day] || groupedSlots[date][0].day}</span>
                                    </div>
                                    <div className="slots-grid">
                                        {groupedSlots[date].map((slot, index) => (
                                            <div 
                                                key={index} 
                                                className="time-slot" 
                                                onClick={() => handleSlotClick(slot)}
                                            >
                                                <strong>{slot.time}</strong>
                                                <div className="barber-name">✂️ {slot.barber_name}</div>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            ))
                        )}
                    </div>
                )}
            </>
        )}

        {/* --- 2. LÉPÉS: RÉSZLETEK ÉS MEGERŐSÍTÉS --- */}
        {step === 2 && selectedSlot && (
            <div className="confirm-step">
                <h2 style={{textAlign: 'center', color: '#d4af37'}}>Foglalás Véglegesítése</h2>
                
                <div style={{
                    background: '#f9f9f9', 
                    padding: '15px', 
                    borderRadius: '8px', 
                    margin: '20px 0', 
                    color: '#333', 
                    border: '1px solid #ddd'
                }}>
                    <p style={{fontSize: '1.1rem', marginBottom: '5px'}}><strong>Dátum:</strong> {selectedSlot.date} ({selectedSlot.time})</p>
                    <p style={{fontSize: '1.1rem'}}><strong>Fodrász:</strong> {selectedSlot.barber_name}</p>
                </div>

                <div className="form-group" style={{marginBottom: '20px'}}>
                    <label style={{fontWeight: 'bold', display: 'block', marginBottom: '8px', color: '#333'}}>Válassz szolgáltatást:</label>
                    <select 
                        value={selectedService} 
                        onChange={(e) => setSelectedService(e.target.value)}
                        style={{
                            width: '100%', 
                            padding: '12px', 
                            borderRadius: '5px', 
                            border: '1px solid #ccc',
                            backgroundColor: 'white',
                            color: '#333',
                            fontSize: '1rem'
                        }}
                    >
                        <option value="">-- Kérlek válassz --</option>
                        {services.map(s => (
                            <option key={s.id} value={s.id}>{s.name}</option>
                        ))}
                    </select>
                </div>

                <div style={{display: 'flex', gap: '10px', marginTop: '30px'}}>
                    <button 
                        onClick={handleBack}
                        style={{flex: 1, padding: '12px', backgroundColor: '#999', color: 'white', border: 'none', borderRadius: '5px', cursor: 'pointer', fontSize: '1rem'}}
                    >
                        Vissza
                    </button>
                    <button 
                        onClick={handleFinalizeBooking}
                        style={{flex: 1, padding: '12px', backgroundColor: '#d4af37', color: 'white', border: 'none', borderRadius: '5px', cursor: 'pointer', fontWeight: 'bold', fontSize: '1rem'}}
                    >
                        LEFOGLALOM ✅
                    </button>
                </div>
            </div>
        )}

      </div>
    </div>
  );
};

export default AppointmentsModal;