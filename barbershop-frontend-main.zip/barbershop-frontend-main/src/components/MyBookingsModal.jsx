import React, { useState, useEffect } from 'react';
import './MyBookingsModal.css';

const MyBookingsModal = ({ onClose }) => {
  const [bookings, setBookings] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('active');

  // Adatok betöltése
  useEffect(() => {
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
      const user = JSON.parse(storedUser);
      
      // Foglalások
      fetch(`http://localhost/Barbershop_Backend/appointments.php?user_id=${user.id}`)
        .then(res => res.json())
        .then(data => setBookings(data))
        .catch(err => console.error(err));

      // Értesítések (get_notifications.php)
      fetch(`http://localhost/Barbershop_Backend/get_notifications.php?user_id=${user.id}`)
        .then(res => res.json())
        .then(data => {
            setNotifications(data);
            setLoading(false);
        })
        .catch(err => setLoading(false));
    }
  }, []);

  // --- ÚJ FUNKCIÓ: ÉRTESÍTÉS BEZÁRÁSA (X gomb logikája) ---
  const dismissNotification = (id) => {
    fetch('http://localhost/Barbershop_Backend/mark_notification_read.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: id })
    })
    .then(res => res.json())
    .then(data => {
        if(data.success) {
            // Ha a szerver visszajelzett, kivesszük a listából, hogy eltűnjön
            setNotifications(notifications.filter(n => n.id !== id));
        }
    });
  };

  // Törlés funkció
  const handleDelete = (id) => {
    if (window.confirm("Biztosan le szeretnéd mondani ezt az időpontot?")) {
      fetch('http://localhost/Barbershop_Backend/delete_booking.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: id })
      })
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          setBookings(bookings.filter(item => item.Idopont_ID !== id));
          alert(data.message);
        } else {
          alert(data.message);
        }
      });
    }
  };

  const now = new Date();
  const upcomingBookings = bookings.filter(b => new Date(b.Kezdes) >= now);
  const pastBookings = bookings.filter(b => new Date(b.Kezdes) < now);

  const renderList = (items, canDelete) => (
    <ul className="bookings-list">
      {items.map((booking) => (
        <li key={booking.Idopont_ID} className={`booking-item ${!canDelete ? 'past-item' : ''}`}>
          <div className="booking-info">
            <div className="booking-date"><strong>{booking.Kezdes}</strong></div>
            <div className="booking-details">
              <span>✂️ {booking.Szolgaltatas_Nev}</span>
              <span>👤 {booking.Fodrasz_Nev}</span>
            </div>
          </div>
          {canDelete && (
            <button className="delete-btn" onClick={() => handleDelete(booking.Idopont_ID)}>🗑️</button>
          )}
        </li>
      ))}
    </ul>
  );

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content bookings-modal" onClick={(e) => e.stopPropagation()}>
        <button className="close-btn" onClick={onClose}>&times;</button>
        <h2>Foglalásaim</h2>

        {/* --- ÉRTESÍTÉSEK X GOMBBAL --- */}
        {notifications.length > 0 && (
            <div className="notifications-box">
                <h3>🔔 Értesítések</h3>
                <ul>
                    {notifications.map((notif) => (
                        <li key={notif.id} style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center'}}>
                            <div>
                                {notif.uzenet} <br/>
                                <small>{notif.datum}</small>
                            </div>
                            {/* ITT AZ X GOMB: */}
                            <button 
                                onClick={() => dismissNotification(notif.id)}
                                style={{background: 'none', border: 'none', cursor: 'pointer', fontSize: '16px', color: '#856404', fontWeight: 'bold'}}
                                title="Bezárás"
                            >
                                ✕
                            </button>
                        </li>
                    ))}
                </ul>
            </div>
        )}

        <div className="modal-tabs">
          <button className={`tab-btn ${activeTab === 'active' ? 'active' : ''}`} onClick={() => setActiveTab('active')}>Aktuális</button>
          <button className={`tab-btn ${activeTab === 'history' ? 'active' : ''}`} onClick={() => setActiveTab('history')}>Korábbi</button>
        </div>

        <div className="modal-body-content">
          {loading ? <p className="loading-text">Betöltés...</p> : (
            activeTab === 'active' ? (upcomingBookings.length > 0 ? renderList(upcomingBookings, true) : <p className="no-data">Nincs aktuális foglalásod.</p>) : 
            (pastBookings.length > 0 ? renderList(pastBookings, false) : <p className="no-data">Nincsenek korábbi foglalásaid.</p>)
          )}
        </div>
      </div>
    </div>
  );
};

export default MyBookingsModal;