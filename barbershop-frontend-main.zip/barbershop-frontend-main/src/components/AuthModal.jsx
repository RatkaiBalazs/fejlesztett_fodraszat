import React, { useState } from 'react';
import './AuthModal.css';

const AuthModal = ({ onClose }) => {
  // view lehet: 'login', 'register' vagy 'reset'
  const [view, setView] = useState('login'); 
  
  // Jelszó láthatóság
  const [showPassword, setShowPassword] = useState(false);

  // Általános adatok
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  
  // Regisztrációs adatok
  const [lastname, setLastname] = useState('');
  const [firstname, setFirstname] = useState('');
  const [phone, setPhone] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  // Jelszó visszaállításhoz
  const [newPassword, setNewPassword] = useState('');

  const [error, setError] = useState('');

  // Nézet váltásakor töröljük a hibaüzeneteket
  const switchView = (newView) => {
    setView(newView);
    setError('');
    setShowPassword(false);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    try {
        if (view === 'login') {
            // --- BEJELENTKEZÉS ---
            const response = await fetch('http://localhost/Barbershop_Backend/login.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password }), 
            });
            const data = await response.json();
            
            if (data.success) {
                if (data.role === 'barber') {
                    // Ha van redirect_url, használjuk, ha nincs, generáljuk
                    if (data.redirect_url) {
                         window.location.href = data.redirect_url;
                    } else {
                         const barberId = data.user.id || data.user.Fodrasz_ID;
                         window.location.href = `http://localhost/Barbershop_Backend/dashboard.php?login_id=${barberId}`;
                    }
                } else {
                    localStorage.setItem('user', JSON.stringify(data.user));
                    alert('Sikeres bejelentkezés! Üdv, ' + data.user.name);
                    onClose();
                    window.location.reload();
                }
            } else {
                setError(data.message);
            }

        } else if (view === 'register') {
            // --- REGISZTRÁCIÓ ---
            if (password !== confirmPassword) {
                setError('A két jelszó nem egyezik!');
                return;
            }

            const fullName = `${lastname} ${firstname}`;
            const response = await fetch('http://localhost/Barbershop_Backend/register.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name: fullName, email, password, phone }),
            });
            const data = await response.json();
            
            if (data.success) {
                alert("Sikeres regisztráció! Most már bejelentkezhetsz.");
                switchView('login');
            } else {
                setError(data.message);
            }

        } else if (view === 'reset') {
            // --- JELSZÓ HELYREÁLLÍTÁS ---
            const response = await fetch('http://localhost/Barbershop_Backend/reset_password.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, phone, new_password: newPassword }),
            });
            const data = await response.json();
            
            if (data.success) {
                alert(data.message);
                switchView('login');
            } else {
                setError(data.message);
            }
        }
    } catch (err) {
        console.error("Hiba:", err);
        setError("Nem sikerült elérni a szervert.");
    }
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <button className="close-btn" onClick={onClose}>&times;</button>
        
        <h2>
            {view === 'login' ? 'Bejelentkezés' : 
             view === 'register' ? 'Regisztráció' : 
             'Új Jelszó Beállítása'}
        </h2>

        {error && <div className="error-message" style={{color: 'red', fontWeight: 'bold', marginBottom: '10px'}}>{error}</div>}

        <form className="auth-form" onSubmit={handleSubmit}>
          
          {view === 'register' && (
            <div className="name-row">
                <div className="form-group">
                    <label>Vezetéknév</label>
                    <input type="text" placeholder="Kovács" value={lastname} onChange={(e) => setLastname(e.target.value)} required />
                </div>
                <div className="form-group">
                    <label>Keresztnév</label>
                    <input type="text" placeholder="János" value={firstname} onChange={(e) => setFirstname(e.target.value)} required />
                </div>
            </div>
          )}

          <div className="form-group">
            {/* JAVÍTVA: Csak "Email cím" felirat */}
            <label>Email cím</label>
            
            {/* TRÜKK: Marad type="text", hogy a fodrász be tudja írni a nevét,
                de a placeholder csak email példát mutat a vendégeknek. */}
            <input 
                type="text" 
                placeholder="pelda@email.com"
                value={email} 
                onChange={(e) => setEmail(e.target.value)} 
                required 
            />
          </div>

          {(view === 'register' || view === 'reset') && (
            <div className="form-group">
                <label>Telefonszám</label>
                <input type="tel" placeholder="+36 30 123 4567" value={phone} onChange={(e) => setPhone(e.target.value)} required />
            </div>
          )}

          <div className="form-group">
            <label>{view === 'reset' ? 'Új jelszó' : 'Jelszó'}</label>
            <div className="password-wrapper">
                <input 
                    type={showPassword ? "text" : "password"} 
                    placeholder="********" 
                    value={view === 'reset' ? newPassword : password}
                    onChange={(e) => view === 'reset' ? setNewPassword(e.target.value) : setPassword(e.target.value)}
                    required 
                />
                <span className="password-toggle-icon" onClick={() => setShowPassword(!showPassword)}>
                    {showPassword ? "👁️" : "🙈"}
                </span>
            </div>
          </div>

          {view === 'register' && (
             <div className="form-group">
                <label>Jelszó megerősítése</label>
                <div className="password-wrapper">
                    <input type={showPassword ? "text" : "password"} placeholder="********" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} required />
                </div>
             </div>
          )}

          <button type="submit" className="login-btn">
            {view === 'login' ? 'Belépés' : view === 'register' ? 'Regisztráció' : 'Mentés'}
          </button>
        </form>
        
        <div className="switch-text" style={{marginTop: '15px'}}>
            {view === 'login' && (
                <>
                    <p>Még nincs fiókod? <span className="link" onClick={() => switchView('register')}>Regisztráció</span></p>
                    <p style={{marginTop: '5px'}}>
                        <span className="link" onClick={() => switchView('reset')} style={{color: '#d4af37'}}>Elfelejtetted a jelszavad?</span>
                    </p>
                </>
            )}
            {view === 'register' && (
                <p>Már van fiókod? <span className="link" onClick={() => switchView('login')}>Belépés</span></p>
            )}
            {view === 'reset' && (
                <p>Eszembe jutott! <span className="link" onClick={() => switchView('login')}>Vissza a belépéshez</span></p>
            )}
        </div>
      </div>
    </div>
  );
};

export default AuthModal;