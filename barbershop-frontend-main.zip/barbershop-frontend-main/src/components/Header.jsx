import React, { useState, useEffect } from 'react';
import './Header.css';

const Header = ({ onOpenAuth, onOpenBookings, onOpenProfile, onOpenAppt }) => {
  const [user, setUser] = useState(null);

  // Ellenőrizzük, hogy be van-e lépve a felhasználó
  useEffect(() => {
    const checkUser = () => {
        const storedUser = localStorage.getItem('user');
        if (storedUser) {
          setUser(JSON.parse(storedUser));
        } else {
          setUser(null);
        }
    };
    
    checkUser();
    // Ha változna a localStorage (pl. kijelentkezés másik tabon), frissítjük
    window.addEventListener('storage', checkUser);
    return () => window.removeEventListener('storage', checkUser);
  }, []);

  const handleLogout = () => {
    if (window.confirm("Biztosan ki szeretnél jelentkezni?")) {
      localStorage.removeItem('user');
      setUser(null);
      window.location.reload();
    }
  };

  // --- 🛑 EZ AZ ÚJ LOGIKA A NAGY GOMBHOZ 🛑 ---
  const handleBookingClick = () => {
    if (!user) {
        // 1. Ha NINCS bejelentkezve -> Üzenet + Login ablak
        alert("A foglaláshoz először be kell jelentkezned!");
        onOpenAuth(); 
    } else {
        // 2. Ha BE VAN jelentkezve -> Foglalás ablak (amit eddig csinált)
        onOpenAppt();
    }
  };

  return (
    <header className="header-container">
      <nav className="navbar">
        <a href="#fooldal" className="logo">BarberShop</a>
        
        <ul className="nav-links">
          <li><a href="#fooldal">Főoldal</a></li>
          <li><a href="#rolunk">Rólunk</a></li>
          <li><a href="#szolgaltatasok">Szolgáltatások</a></li>
          <li><a href="#barberek">Csapatunk</a></li>
          <li><a href="#kepek">Galéria</a></li>
          <li><a href="#elerhetosegek">Kapcsolat</a></li>
        </ul>

        <div className="auth-section">

          {/* --- A GOMB MOST MÁR AZ ÚJ FÜGGVÉNYT HÍVJA --- */}
          <button 
            onClick={handleBookingClick} 
            style={{
                backgroundColor: '#d3ad7f', 
                color: 'white',
                border: 'none',
                padding: '8px 15px',
                borderRadius: '5px',
                cursor: 'pointer',
                fontWeight: 'bold',
                marginRight: '15px',
                fontSize: '0.9rem',
                boxShadow: '0 2px 5px rgba(0,0,0,0.2)'
            }}
          >
            FOGLALÁS +
          </button>

          {user ? (
            // HA BE VAN LÉPVE
            <div className="logged-in-user">
              <span className="user-greeting">Szia, {user.name ? user.name.split(' ')[1] : (user.TeljesNev || 'Vendég')}!</span>
              
              <button 
                className="profile-btn" 
                onClick={onOpenProfile} 
                title="Profil szerkesztése"
                style={{
                    background: 'none', 
                    border: 'none', 
                    cursor: 'pointer', 
                    fontSize: '1.2rem',
                    marginRight: '10px'
                }}
              >
                ✏️
              </button>

              <button className="my-bookings-btn" onClick={onOpenBookings} title="Foglalásaim">
                📅
              </button>

              <button className="logout-btn" onClick={handleLogout} title="Kijelentkezés">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg>
              </button>
            </div>
          ) : (
            // HA NINCS BELÉPVE
            <div className="user-icon" onClick={onOpenAuth} title="Belépés / Regisztráció">
              <span className="login-text">Belépés</span>
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="icon"><path fillRule="evenodd" d="M7.5 6a4.5 4.5 0 119 0 4.5 4.5 0 01-9 0zM3.751 20.105a8.25 8.25 0 0116.498 0 .75.75 0 01-.437.695A18.683 18.683 0 0112 22.5c-2.786 0-5.433-.608-7.812-1.7a.75.75 0 01-.437-.695z" clipRule="evenodd" /></svg>
            </div>
          )}
        </div>
      </nav>
    </header>
  );
};

export default Header;