import React, { useState, useEffect } from 'react';
import './App.css';

// Komponensek
import Header from './components/Header';
import AuthModal from './components/AuthModal';
import MyBookingsModal from './components/MyBookingsModal';
import ProfileModal from './components/ProfileModal';
import AppointmentsModal from './components/AppointmentsModal';

// Oldalak importálása
import Főoldal from './pages/Főoldal';
import Szolgáltatások from './pages/Szolgáltatások';
import Barberek from './pages/Barberek';
import Képek from './pages/Képek';
import Rolunk from './pages/Rolunk';
import Elerhetosegek from './pages/Elerhetosegek';

// ❌ TÖRÖLTÜK A BarberDashboard IMPORTOT! (Már nem kell)

function App() {
  const [user, setUser] = useState(null);

  // --- MODAL ÁLLAPOTOK ---
  const [isAuthModalOpen, setAuthModalOpen] = useState(false); 
  const [isBookingsModalOpen, setBookingsModalOpen] = useState(false); 
  const [isProfileModalOpen, setProfileModalOpen] = useState(false);
  const [isApptModalOpen, setApptModalOpen] = useState(false);

  // --- BETÖLTÉS ---
  useEffect(() => {
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
  }, []);

  // --- FÜGGVÉNYEK ---
  const openAuthModal = () => setAuthModalOpen(true);
  const closeAuthModal = () => setAuthModalOpen(false);

  const openBookingsModal = () => setBookingsModalOpen(true);
  const closeBookingsModal = () => setBookingsModalOpen(false);

  const openProfileModal = () => setProfileModalOpen(true);
  const closeProfileModal = () => setProfileModalOpen(false);

  const openApptModal = () => setApptModalOpen(true);
  const closeApptModal = () => setApptModalOpen(false);

  // --- SCROLL ANIMÁCIÓ ---
  useEffect(() => {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('show');
        } else {
          entry.target.classList.remove('show');
        }
      });
    });

    const hiddenElements = document.querySelectorAll('.hidden');
    hiddenElements.forEach((el) => observer.observe(el));
    
    return () => observer.disconnect();
  }, []);

  // --- JAVÍTÁS: ÁTIRÁNYÍTÁS A PHP FÁJLRA ---
  if (user && user.role === 'barber') {
      // Mivel a PHP kódod várja a '?login_id=' paramétert, így adjuk át:
      // FONTOS: Ellenőrizd, hogy a mappa neve nálad is 'Barbershop_Backend'!
      // Ha az ID-t 'id' néven mentetted el loginnal, akkor user.id, ha 'Fodrasz_ID', akkor azt írd!
      const barberId = user.id || user.Fodrasz_ID; 
      
      window.location.href = `http://localhost/Barbershop_Backend/dashboard.php?login_id=${barberId}`;
      return null; // Nem rajzolunk ki semmit Reactban, mert épp elhagyjuk az oldalt
  }

  // --- HA VENDÉG, AKKOR A REACT WEBOLDALT MUTATJUK ---
  return (
    <div className="App">
      <Header 
        onOpenAuth={openAuthModal} 
        onOpenBookings={openBookingsModal} 
        onOpenProfile={openProfileModal}
        onOpenAppt={openApptModal} 
      />

      {/* MODÁLOK */}
      {isAuthModalOpen && <AuthModal onClose={closeAuthModal} />}
      {isBookingsModalOpen && <MyBookingsModal onClose={closeBookingsModal} />}
      {isProfileModalOpen && <ProfileModal onClose={closeProfileModal} />}
      {isApptModalOpen && <AppointmentsModal onClose={closeApptModal} />}

      {/* SZEKCIÓK */}
      <section id="fooldal" className="hidden">
        <Főoldal 
          onOpenAuth={openAuthModal} 
          onOpenBookings={openBookingsModal} 
          onOpenAppt={openApptModal}
        />
      </section>

      <section id="rolunk" className="hidden">
        <Rolunk />
      </section>

      <section id="szolgaltatasok" className="hidden">
        <Szolgáltatások />
      </section>

      <section id="barberek" className="hidden">
        <Barberek onOpenAuth={openAuthModal} />
      </section>

      <section id="kepek" className="hidden">
        <Képek />
      </section>

      <section id="elerhetosegek" className="hidden">
        <Elerhetosegek />
      </section>

    </div>
  );
}

export default App;