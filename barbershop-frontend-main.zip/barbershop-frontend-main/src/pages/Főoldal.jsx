import React from 'react';
import './Főoldal.css';

const Főoldal = ({ onOpenAuth, onOpenBookings }) => {

  // Ez a függvény dönti el, hogy mit csináljunk
  const handleAction = (actionType) => {
    // 1. Megnézzük, be van-e lépve a felhasználó
    const user = localStorage.getItem('user');

    if (!user) {
      // HA NINCS BELÉPVE -> Nyissuk meg a belépő ablakot!
      onOpenAuth();
    } else {
      // HA BE VAN LÉPVE -> Csináljuk a kért műveletet!
      
      if (actionType === 'booking') {
        // Ha foglalni akar: Görgessünk le a Barberekhez!
        const section = document.getElementById('barberek');
        if (section) {
          section.scrollIntoView({ behavior: 'smooth' });
        }
      } 
      
      else if (actionType === 'cancel') {
        // Ha lemondani akar: Nyissuk meg a Foglalásaim ablakot!
        onOpenBookings();
      }
    }
  };

  return (
    <div className="hero-container">
      <div className="hero-content">
        <h1>BARBER SHOP</h1>
        <p>A stílus, ami hozzád illik.</p>
        
        <div className="hero-buttons">
          
          {/* Sárga gomb: FOGLALÁS */}
          <button 
            className="btn-main orange-btn" 
            onClick={() => handleAction('booking')}
          >
            IDŐPONTFOGLALÁS
          </button>

          {/* Piros gomb: LEMONDÁS */}
          <button 
            className="btn-main red-btn" 
            onClick={() => handleAction('cancel')}
          >
            IDŐPONT LEMONDÁSA
          </button>

        </div>

      </div>
    </div>
  );
};

export default Főoldal;