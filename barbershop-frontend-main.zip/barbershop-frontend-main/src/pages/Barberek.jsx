import React, { useState, useEffect } from 'react';
import './Barberek.css';

// --- FONTOS: Ellenőrizd, hol van a ReviewsModal fájlod! ---
// Ha a 'components' mappában van (ajánlott):
import ReviewsModal from '../components/ReviewsModal';
// Ha közvetlenül a Barberek.jsx mellett van:
// import ReviewsModal from './ReviewsModal'; 

const Barberek = ({ onOpenAuth }) => {
  const [selectedBarber, setSelectedBarber] = useState(null); // Foglaláshoz
  const [reviewBarber, setReviewBarber] = useState(null);     // Véleményekhez
  const [ratings, setRatings] = useState({});                 // Csillagok tárolása
  const [isLoading, setIsLoading] = useState(false);          // Töltés jelző
  
  const [bookingData, setBookingData] = useState({
    date: '',
    time: '',
    service_id: '1'
  });

  const barbers = [
    {
      id: 1, name: "Kovács Dávid", role: "Master Barber",
      desc: "10 év tapasztalattal a klasszikus vágások szakértője.",
      image: "https://cdn.britannica.com/65/227665-050-D74A477E/American-actor-Leonardo-DiCaprio-2016.jpg" 
    },
    {
      id: 2, name: "Nagy Aliz", role: "Szakáll Specialista",
      desc: "Forró törölközős borotválásban verhetetlen.",
      image: "https://s.yimg.com/ny/api/res/1.2/ABv9asL4IBaRBtZ9zzZh1A--/YXBwaWQ9aGlnaGxhbmRlcjt3PTIwMDA7aD0xMzAwO2NmPXdlYnA-/https://media.zenfs.com/en/bang_showbiz_628/24d634077ef83b1e61a8e8cce1883aac"
    },
    {
      id: 3, name: "Szabó Péter", role: "Modern Stylist",
      desc: "A legújabb trendek követője.",
      image: "https://assets.fxnetworks.com/fx/950c40a9-c758-426a-a2f9-be192d3fc395.jpg" 
    }
  ];

  // --- 1. Csillagok lekérése betöltéskor ---
  useEffect(() => {
    fetch('http://localhost/Barbershop_Backend/get_ratings_summary.php')
        .then(res => res.json())
        .then(data => setRatings(data))
        .catch(err => console.error("Hiba a csillagok lekérésekor:", err));
  }, []);

  // Segédfüggvény a csillagok kirajzolásához
  const renderStars = (barberName) => {
    const stat = ratings[barberName];
    if (!stat) return <span className="no-rating">Még nincs értékelés</span>;

    const fullStars = Math.floor(stat.atlag);
    const hasHalfStar = stat.atlag % 1 >= 0.5;
    
    return (
        <div className="star-display" title={`${stat.atlag} / 5`}>
            <span className="star-icon">{"★".repeat(fullStars)}</span>
            {hasHalfStar && <span className="star-icon">½</span>}
            <span className="star-icon empty">{"☆".repeat(5 - fullStars - (hasHalfStar ? 1 : 0))}</span>
            <span className="rating-count">({stat.db})</span>
        </div>
    );
  };

  const serviceDurations = { '1': 30, '2': 15, '3': 45, '4': 60, '5': 20 };

  const initiateBooking = (barber) => {
    const storedUser = localStorage.getItem('user');
    if (!storedUser) {
        alert("A foglaláshoz először be kell jelentkezned!"); 
        onOpenAuth(); 
        return; 
    }
    setSelectedBarber(barber); 
  };

  // --- 2. GYORSFOGLALÁS LOGIKA ---
  const handleQuickBooking = async () => {
    const storedUser = localStorage.getItem('user');
    if (!storedUser) {
        alert("A gyorsfoglaláshoz először be kell jelentkezned!"); 
        onOpenAuth(); 
        return; 
    }
    setIsLoading(true);
    try {
        const response = await fetch('http://localhost/Barbershop_Backend/get_earliest_slot.php');
        const data = await response.json();
        
        if (data.success) {
            const foundBarber = barbers.find(b => b.id == data.barber.id) || {
                id: data.barber.id, name: data.barber.name, role: "Barber", desc: "Elérhető szakember", image: "https://via.placeholder.com/150"
            };
            setSelectedBarber(foundBarber);
            setBookingData({ date: data.date, time: data.time, service_id: '1' });
            
            alert(`Találtunk egy szabad helyet!\n\nFodrász: ${foundBarber.name}\nDátum: ${data.date}\nIdőpont: ${data.time}\n\nHa megfelel, kattints a 'Lefoglalás' gombra!`);
        } else {
            alert(data.message);
        }
    } catch (error) { console.error(error); alert("Hiba történt."); } 
    finally { setIsLoading(false); }
  };

  // --- 3. IDŐPONT GENERÁTOR (30 perces, szűrt) ---
  const generateTimeSlots = () => {
    if (!bookingData.date) return [];
    const date = new Date(bookingData.date);
    const day = date.getDay(); 
    const now = new Date();
    const todayStr = now.getFullYear() + '-' + String(now.getMonth() + 1).padStart(2, '0') + '-' + String(now.getDate()).padStart(2, '0');
    const isToday = (bookingData.date === todayStr);

    if (day === 0) return []; // Vasárnap üres tömböt ad vissza
    let startHour = 9; let endHour = 20;
    if (day === 6) { startHour = 10; endHour = 16; }

    const slots = [];
    for (let hour = startHour; hour < endHour; hour++) {
        for (let minute = 0; minute < 60; minute += 30) {
            if (isToday) {
                const currentHour = now.getHours();
                const currentMinute = now.getMinutes();
                if (hour < currentHour) continue; 
                if (hour === currentHour && minute <= currentMinute) continue;
            }
            const formattedHour = hour.toString().padStart(2, '0');
            const formattedMinute = minute.toString().padStart(2, '0');
            slots.push(`${formattedHour}:${formattedMinute}`);
        }
    }
    return slots;
  };

  const timeSlots = generateTimeSlots(); 

  const handleBooking = async () => {
    const storedUser = localStorage.getItem('user');
    if (!storedUser) return;
    const user = JSON.parse(storedUser);
    if (!bookingData.date || !bookingData.time) { alert("Kérlek válassz dátumot és időpontot!"); return; }

    const payload = {
      user_id: user.id || user.Ugyfel_ID, 
      employee_id: selectedBarber.id, 
      service_id: bookingData.service_id,
      date: bookingData.date,
      time: bookingData.time
    };

    try {
      const response = await fetch('http://localhost/Barbershop_Backend/booking.php', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload)
      });
      const data = await response.json();
      if (data.success) {
        alert("✅ Sikeres foglalás! Köszönjük, " + (user.name || user.TeljesNev || "Vendég") + "!");
        setSelectedBarber(null); 
        setBookingData({ ...bookingData, date: '', time: '' }); 
      } else { alert("❌ Hiba: " + data.message); }
    } catch (error) { console.error(error); alert("Nem sikerült elérni a szervert."); }
  };

  return (
    <div className="barbers-container">
      <h2>Ismerd meg csapatunkat</h2>
      <p className="subtitle">Válassz szakembert és foglalj időpontot!</p>

      {/* --- GYORSFOGLALÁS GOMB --- */}
      <div style={{ textAlign: 'center', marginBottom: '30px' }}>
          <button 
            onClick={handleQuickBooking} 
            disabled={isLoading} 
            className="quick-book-btn"
            style={{
                background: 'linear-gradient(45deg, #f39c12, #d35400)',
                color: 'white',
                border: 'none',
                padding: '15px 30px',
                fontSize: '1.2rem',
                fontWeight: 'bold',
                borderRadius: '50px',
                cursor: 'pointer',
                boxShadow: '0 4px 15px rgba(243, 156, 18, 0.4)',
                transition: 'transform 0.2s',
            }}
            onMouseOver={(e) => e.currentTarget.style.transform = 'scale(1.05)'}
            onMouseOut={(e) => e.currentTarget.style.transform = 'scale(1)'}
          >
            {isLoading ? 'Keresés...' : '⚡ Legközelebbi Szabad Időpont (Bárkihez)'}
          </button>
      </div>

      <div className="barbers-list">
        {barbers.map((barber) => (
          <div key={barber.id} className="barber-card">
            <div className="barber-image-wrapper">
              <img src={barber.image} alt={barber.name} className="barber-img" />
            </div>
            <div className="barber-info">
              <h3>{barber.name}</h3>
              <span className="role">{barber.role}</span>
              
              {/* --- CSILLAGOK --- */}
              <div className="rating-container">
                  {renderStars(barber.name)}
              </div>

              <p>{barber.desc}</p>
              
              {/* --- GOMBOK --- */}
              <div className="card-actions">
                  <button className="book-barber-btn" onClick={() => initiateBooking(barber)}>
                    Időpontfoglalás
                  </button>

                  <button 
                    className="review-icon-btn" 
                    onClick={() => setReviewBarber(barber)}
                    title="Vélemények olvasása"
                  >
                    💬
                  </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* --- FOGLALÁSI MODAL --- */}
      {selectedBarber && (
        <div className="booking-modal-overlay">
          <div className="booking-modal-content">
            <h3>Foglalás: {selectedBarber.name}</h3>
            
            <label>Dátum:</label>
            <input 
              type="date" 
              required 
              min={new Date().toISOString().split('T')[0]} 
              value={bookingData.date} 
              onChange={(e) => setBookingData({...bookingData, date: e.target.value, time: ''})} 
            />

            <label>Időpont:</label>
            <select 
                required 
                value={bookingData.time} 
                onChange={(e) => setBookingData({...bookingData, time: e.target.value})} 
                disabled={!bookingData.date} 
                style={!bookingData.date ? {backgroundColor: '#e9e9e9', cursor: 'not-allowed'} : {}}
            >
                <option value="">
                    {bookingData.date 
                        ? (timeSlots.length === 0 
                            ? (new Date(bookingData.date).getDay() === 0 
                                ? "-- Vasárnap ZÁRVA vagyunk --"  // <--- ITT A JAVÍTÁS!
                                : "-- Nincs szabad hely --") 
                            : "-- Válassz időpontot --")
                        : "-- Előbb válassz dátumot --"
                    }
                </option>
                {bookingData.time && !timeSlots.includes(bookingData.time) && <option value={bookingData.time}>{bookingData.time}</option>}
                {timeSlots.map((slot, index) => <option key={index} value={slot}>{slot}</option>)}
            </select>

            <label>Szolgáltatás:</label>
            <select value={bookingData.service_id} onChange={(e) => setBookingData({...bookingData, service_id: e.target.value})}>
                <option value="1">Hajvágás (30p)</option>
                <option value="2">Szakáll vágás (15p)</option>
                <option value="3">Szakáll + Hajvágás (45p)</option>
                <option value="4">Hajfestés (60p)</option>
                <option value="5">Igazítás (20p)</option>
            </select>

            <div className="modal-actions">
              <button className="cancel-btn" onClick={() => setSelectedBarber(null)}>Mégse</button>
              <button className="confirm-btn" onClick={handleBooking}>Lefoglalás</button>
            </div>
          </div>
        </div>
      )}

      {/* --- VÉLEMÉNYEK MODAL --- */}
      {reviewBarber && (
        <ReviewsModal 
            barber={reviewBarber} 
            onClose={() => setReviewBarber(null)} 
            user={localStorage.getItem('user') ? JSON.parse(localStorage.getItem('user')) : null}
        />
      )}
    </div>
  );
};

export default Barberek;